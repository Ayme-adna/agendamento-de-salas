import axios from "axios";
import type { DataBloqueada, FiltroSalas, Intervalo, Professor, ProfessorIn, Regras, Reserva, ReservaCreate, Sala, SalaAdmin, SalaIn, Sessao, Usuario } from "./types";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000",
  timeout: 15000,
});
const TOKEN_KEY = "salafacil.token";
export const EVENTO_SESSAO_EXPIRADA = "salafacil:sessao-expirada";
export const EVENTO_ATUALIZAR = "salafacil:atualizar";

function lerToken() {
  try { return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY); } catch { return null; }
}
export function encerrarSessao() {
  try { localStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(TOKEN_KEY); } catch { /* sem storage */ }
}
export function temSessao() { return Boolean(lerToken()); }
function salvarToken(token: string, manter: boolean) {
  encerrarSessao();
  try { (manter ? localStorage : sessionStorage).setItem(TOKEN_KEY, token); } catch { /* sem storage */ }
}

api.interceptors.request.use((config) => {
  const token = lerToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
api.interceptors.response.use((r) => r, (error) => {
  const url = error.config?.url ?? "";
  if (axios.isAxiosError(error) && error.response?.status === 401 && !url.startsWith("/auth/login") && !url.startsWith("/auth/cadastro")) {
    encerrarSessao();
    window.dispatchEvent(new Event(EVENTO_SESSAO_EXPIRADA));
  }
  return Promise.reject(error);
});

export function mensagemErro(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const detail = error.response?.data?.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) return "Confira os campos preenchidos e tente novamente.";
    if (!error.response) return "Não foi possível conectar ao servidor. Verifique se a API está em execução.";
  }
  return "Não foi possível concluir a operação. Tente novamente.";
}

export async function entrar(login: string, senha: string, manter: boolean): Promise<Usuario> {
  const { data } = await api.post<Sessao>("/auth/login", { login, senha });
  salvarToken(data.access_token, manter);
  return data.usuario;
}
export async function cadastrar(nome: string, login: string, senha: string): Promise<Usuario> {
  const { data } = await api.post<Sessao>("/auth/cadastro", { nome, login, senha });
  salvarToken(data.access_token, true);
  return data.usuario;
}
export const getUsuario = async () => (await api.get<Usuario>("/auth/me")).data;
export const getRegras = async () => (await api.get<Regras>("/regras")).data;
export const getSalas = async (filtro: FiltroSalas = {}) => (await api.get<Sala[]>("/salas", { params: filtro })).data;
export const getDisponibilidade = async (salaId: number, data: string) =>
  (await api.get<{ ocupados: Intervalo[] }>(`/salas/${salaId}/disponibilidade`, { params: { data } })).data.ocupados;
export const getReservas = async () => (await api.get<Reserva[]>("/reservas")).data;
export const criarReserva = async (dados: ReservaCreate) => (await api.post<Reserva>("/reservas", dados)).data;
export const cancelarReserva = async (id: number) => (await api.patch<Reserva>(`/reservas/${id}/cancelar`)).data;

// ---------- Administração (somente professores) ----------
export const admin = {
  salas: async () => (await api.get<SalaAdmin[]>("/admin/salas")).data,
  criarSala: async (dados: SalaIn) => (await api.post<SalaAdmin>("/admin/salas", dados)).data,
  editarSala: async (id: number, dados: SalaIn) => (await api.put<SalaAdmin>(`/admin/salas/${id}`, dados)).data,
  ativarSala: async (id: number, ativo: boolean) => (await api.patch<SalaAdmin>(`/admin/salas/${id}/ativa`, { ativo })).data,
  professores: async () => (await api.get<Professor[]>("/admin/professores")).data,
  criarProfessor: async (dados: ProfessorIn) => (await api.post<Professor>("/admin/professores", dados)).data,
  ativarProfessor: async (id: number, ativo: boolean) => (await api.patch<Professor>(`/admin/professores/${id}/ativo`, { ativo })).data,
  datas: async () => (await api.get<DataBloqueada[]>("/admin/datas-bloqueadas")).data,
  bloquearData: async (data: string, motivo: string) => (await api.post<DataBloqueada>("/admin/datas-bloqueadas", { data, motivo })).data,
  desbloquearData: async (id: number) => { await api.delete(`/admin/datas-bloqueadas/${id}`); },
};
