# SalaFácil

Sistema de reserva de salas para instituições de ensino, com **dois perfis em um só sistema**:

- **Professores** agendam aulas em qualquer sala, com horário livre. Também acompanham a agenda semanal de toda a instituição, incluindo as reservas de alunos.
- **Alunos** se cadastram sozinhos e reservam **salas de estudo em grupo** em períodos de 2 horas, com limite de 2h por dia. Recebem um comprovante com código e podem cancelar.

Este projeto une o **reservaSala** (base de layout, stack e área do professor) com o **agendamento-de-salas** (fluxo do aluno, fotos e regras de reserva). O trabalho foi feito para a disciplina **Análise e Projeto de Sistemas II**, do curso de **Sistemas de Informação**.

## Tecnologias

- **Frontend:** React, TypeScript e Vite
- **Backend:** Python, FastAPI e SQLAlchemy
- **Banco de dados:** MySQL

## Estrutura

```
schema.sql                 → cria o banco "salafacil" com dados de exemplo
backend/
  app/main.py              → cria a API e registra as rotas
  app/config.py            → conexão, fuso e REGRAS ajustáveis (blocos do aluno, limite diário)
  app/models.py            → tabelas usuarios, salas, reservas
  app/schemas.py           → formatos de entrada/saída da API
  app/seguranca.py         → hash de senha, token de sessão, autenticação
  app/regras.py            → conflitos de horário, status, conversões
  app/routers/             → auth.py, salas.py, reservas.py, admin.py
  tests/test_api.py        → 35 testes (SQLite em memória)
  requirements.txt
frontend/
  public/img/              → fotos das salas
  src/App.tsx              → login e direcionamento por perfil
  src/componentes/         → Layout (sidebar + topbar), Login, Comprovante, modais
  src/professor/           → área do professor (Início, Agendamentos, Salas, Administração)
  src/aluno/               → área do aluno (Início, Buscar salas, Minhas reservas)
```

## Regras de negócio

| | Professor | Aluno |
|---|---|---|
| Acesso | Cadastrado por outro professor (Administração) | Autocadastro com matrícula ou e-mail |
| Salas | Todas | Só as marcadas com `permite_aluno` |
| Horário | Intervalo livre, dentro do funcionamento | Blocos fixos: 10–12, 12–14, 14–16, 16–18 (sábado só 10–12) |
| Limite | — | 2h por dia; até a capacidade da sala |
| Agenda | Vê todas as reservas (as de alunos aparecem com a etiqueta "Aluno") | Vê só as próprias |
| Cancelar | As próprias, antes do início | As próprias, antes do início |
| Administração | Salas, professores e datas bloqueadas | — |

Regras que valem para todos:

- **funcionamento:** segunda a sexta das 07h às 22h e sábado das 07h às 12h; domingo fechado;
- **datas bloqueadas** (feriados, recessos), cadastradas pelos professores, não aceitam reservas;
- **uma sala por pessoa no mesmo horário:** ninguém pode ter duas reservas sobrepostas, mesmo em salas diferentes;
- não pode haver duas reservas sobrepostas na mesma sala;
- só se reserva data e hora futuras;
- a reserva é confirmada na hora;
- o status "Concluída" é calculado automaticamente quando o horário termina.

Os blocos do aluno, o limite diário e o horário de funcionamento (`FUNCIONAMENTO`) ficam em `backend/app/config.py`. O frontend lê essas regras da API (`GET /regras`), então basta mudar em um lugar.

## Pré-requisitos

Python, Node.js com npm e MySQL instalados. O serviço do MySQL precisa estar em execução. Os comandos abaixo são para **PowerShell no Windows**.

## 1. Banco de dados

Abra `schema.sql` no MySQL Workbench e execute o script.

> ⚠️ O script **apaga e recria** o banco `salafacil`.

Usuários de exemplo (senha `123456` para os dois):

| Perfil | Login |
|---|---|
| Professor | `carla.furtado@escola.edu.br` |
| Aluno | `2026001` (ou `lucas.andrade@aluno.escola.edu.br`) |

Novos professores são cadastrados na tela **Administração → Professores**, por qualquer professor logado. Também dá para inserir direto na tabela `usuarios` com `perfil = 'professor'`; nesse caso a senha pode ir em texto puro, porque ela é convertida para hash no primeiro login.

## Administração (menu do professor)

- **Salas:** cadastrar, editar e desativar (não há exclusão, para manter o histórico). Uma sala com reservas futuras não pode ser desativada, nem ter a capacidade reduzida abaixo de uma reserva existente, nem ser fechada para alunos se houver reservas de alunos.
- **Professores:** cadastrar com senha inicial e ativar ou desativar o acesso. Ao desativar, as reservas futuras do professor são canceladas automaticamente e as salas ficam livres (uma aula já em andamento é mantida). Ninguém pode desativar o próprio acesso.
- **Datas bloqueadas:** bloquear e liberar datas. Uma data que já tem reservas confirmadas só pode ser bloqueada depois que elas forem canceladas.

## 2. Backend

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

Por padrão, a API conecta em `root` sem senha no `localhost:3306`. Se o seu MySQL for diferente, defina a variável antes de iniciar:

```powershell
$env:DATABASE_URL = "mysql+mysqlconnector://usuario:senha@localhost:3306/salafacil"
```

A documentação interativa fica em <http://localhost:8000/docs>.

## 3. Frontend

Em outro terminal:

```powershell
cd frontend
npm.cmd install
npm.cmd run dev -- --port 5173 --strictPort
```

Acesse <http://localhost:5173>.

## Configurações opcionais

| Variável | Onde | Para quê |
|---|---|---|
| `DATABASE_URL` | terminal do backend | conexão com o MySQL |
| `FRONTEND_ORIGINS` | terminal do backend | origens liberadas no CORS (padrão: `localhost:5173`) |
| `SESSION_SECRET` | terminal do backend | segredo fixo dos tokens; sem ele, reiniciar a API exige novo login |
| `VITE_API_URL` | `frontend/.env.local` | endereço da API (padrão: `http://localhost:8000`) |

## Verificações

```powershell
# testes do backend (pasta backend)
.\.venv\Scripts\python.exe -m unittest discover -s tests -v

# checagem de tipos + build do frontend (pasta frontend)
npm.cmd run build
```

## Principais rotas da API

| Método | Rota | Descrição |
|---|---|---|
| POST | `/auth/login` | Entrar com e-mail ou matrícula |
| POST | `/auth/cadastro` | Autocadastro de aluno (já devolve a sessão) |
| GET | `/auth/me` | Usuário logado |
| GET | `/regras` | Blocos do aluno, limite diário, funcionamento e datas bloqueadas |
| GET | `/salas?data=&inicio=&fim=&pessoas=&busca=` | Salas visíveis ao perfil, com status atual e disponibilidade no período |
| GET | `/salas/{id}` | Detalhe da sala |
| GET | `/salas/{id}/disponibilidade?data=` | Horários ocupados no dia, sem mostrar quem reservou |
| GET | `/reservas` | Agenda geral (professor) ou minhas reservas (aluno) |
| POST | `/reservas` | Criar reserva |
| GET | `/reservas/codigo/{codigo}` | Comprovante |
| PATCH | `/reservas/{id}/cancelar` | Cancelar a própria reserva |
| GET/POST | `/admin/salas` | Listar todas e cadastrar sala (professor) |
| PUT | `/admin/salas/{id}` | Editar sala |
| PATCH | `/admin/salas/{id}/ativa` | Ativar ou desativar sala |
| GET/POST | `/admin/professores` | Listar e cadastrar professor |
| PATCH | `/admin/professores/{id}/ativo` | Ativar ou desativar professor |
| GET/POST | `/admin/datas-bloqueadas` | Listar e bloquear data |
| DELETE | `/admin/datas-bloqueadas/{id}` | Liberar data |
