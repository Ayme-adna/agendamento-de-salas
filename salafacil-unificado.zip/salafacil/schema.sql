-- SalaFácil — banco unificado (professores + alunos)
-- ATENÇÃO: este script recria o banco do zero e apaga os dados existentes.
SET NAMES utf8mb4;
DROP DATABASE IF EXISTS salafacil;
CREATE DATABASE salafacil CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE salafacil;

-- Usuários: professores (cadastrados aqui/pela instituição) e alunos (cadastro pelo site).
-- O login aceita e-mail OU matrícula; pelo menos um dos dois é obrigatório.
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(150) NULL UNIQUE,
    matricula VARCHAR(30) NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,                       -- hash pbkdf2_sha256
    perfil ENUM('aluno', 'professor') NOT NULL DEFAULT 'aluno',
    cargo VARCHAR(100) NULL,                           -- texto exibido (ex.: "Professora de Biologia")
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_usuario_login CHECK (email IS NOT NULL OR matricula IS NOT NULL)
);

-- Salas: une os dados dos dois projetos (nome/bloco do SalaFácil + andar/recursos/foto do portal do aluno).
-- permite_aluno = TRUE indica que a sala aparece para alunos.
CREATE TABLE salas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    tipo VARCHAR(50) NOT NULL DEFAULT 'Sala de aula',
    bloco VARCHAR(50) NOT NULL,
    andar INT NOT NULL DEFAULT 0,
    campus VARCHAR(100) NOT NULL DEFAULT 'Campus Principal',
    capacidade INT NOT NULL,
    recursos VARCHAR(255) NULL,                        -- separados por " • "
    descricao VARCHAR(500) NULL,
    imagem VARCHAR(100) NULL,                          -- arquivo em frontend/public/img
    permite_aluno BOOLEAN NOT NULL DEFAULT FALSE,
    ativa BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT ck_sala_capacidade CHECK (capacidade > 0)
);

-- Reservas: substitui "agendamentos". Horário em colunas TIME (antes era texto "10:00 - 11:30").
-- "Concluída" não é gravada: é calculada pela API quando o horário já passou.
CREATE TABLE reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,                -- código do comprovante (ex.: SF-2026-48213)
    sala_id INT NOT NULL,
    usuario_id INT NOT NULL,
    data DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    atividade VARCHAR(200) NOT NULL,                   -- aula (professor) ou finalidade (aluno)
    pessoas INT NULL,
    status ENUM('confirmada', 'cancelada') NOT NULL DEFAULT 'confirmada',
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cancelada_em DATETIME NULL,
    CONSTRAINT fk_reserva_sala FOREIGN KEY (sala_id) REFERENCES salas(id),
    CONSTRAINT fk_reserva_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    CONSTRAINT ck_reserva_horario CHECK (hora_inicio < hora_fim),
    INDEX ix_reserva_sala_data (sala_id, data),
    INDEX ix_reserva_usuario_data (usuario_id, data)
);

-- Datas sem reservas (feriados, recessos). Cadastradas pelos professores na tela de Administração.
CREATE TABLE datas_bloqueadas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data DATE NOT NULL UNIQUE,
    motivo VARCHAR(150) NOT NULL,
    criado_por INT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bloqueio_usuario FOREIGN KEY (criado_por) REFERENCES usuarios(id)
);

-- Usuários de exemplo — senha de ambos: 123456
INSERT INTO usuarios (nome, email, matricula, senha, perfil, cargo) VALUES
('Carla Furtado', 'carla.furtado@escola.edu.br', NULL,
 'pbkdf2_sha256$c2cb9aa6ecb77d3c2ca2722561cfc490$6043d6c1a5a97b1f2dd70fc9e5061239a16cffcaca8dc9aeba828d50b476335b',
 'professor', 'Coordenação pedagógica'),
('Lucas Andrade', 'lucas.andrade@aluno.escola.edu.br', '2026001',
 'pbkdf2_sha256$780bfe30e5d62979cdd480a93ee06ff3$af2d0ff67e9052fc71f9418545886108985f125a4d794a26c5299338ea8d6f93',
 'aluno', 'Sistemas de Informação');

-- Salas de aula / laboratórios (uso de professores)
INSERT INTO salas (codigo, nome, tipo, bloco, andar, capacidade, recursos, descricao, permite_aluno) VALUES
('A101', 'Sala 101', 'Sala de aula', 'Bloco A', 1, 30, 'Wi-Fi • Quadro branco • Projetor', 'Sala de aula tradicional com carteiras individuais.', FALSE),
('B204', 'Sala 204', 'Sala de aula', 'Bloco B', 2, 40, 'Wi-Fi • Quadro branco • Projetor', 'Sala ampla para turmas grandes.', FALSE),
('C002', 'Lab. 02', 'Laboratório', 'Bloco C', 0, 24, 'Wi-Fi • Projetor • Computadores', 'Laboratório de informática com 24 estações.', FALSE),
('A000', 'Auditório', 'Auditório', 'Bloco A', 0, 120, 'Wi-Fi • Projetor • Som', 'Auditório para palestras e eventos.', FALSE),
('C010', 'Sala Maker', 'Laboratório', 'Bloco C', 0, 20, 'Wi-Fi • Bancadas • Ferramentas', 'Espaço de prototipação e projetos práticos.', FALSE);

-- Salas de estudo em grupo (alunos e professores)
INSERT INTO salas (codigo, nome, tipo, bloco, andar, capacidade, recursos, descricao, imagem, permite_aluno) VALUES
('C217', 'Sala C217', 'Estudo em grupo', 'Bloco C', 2, 20, 'Wi-Fi • Quadro branco • Projetor', 'Ambiente iluminado e confortável para trabalhos em equipe, com mesa compartilhada e isolamento acústico.', 'C217.jpg', TRUE),
('A105', 'Sala A105', 'Estudo em grupo', 'Bloco A', 1, 15, 'Wi-Fi • Quadro branco', 'Sala aconchegante para revisão de conteúdos e troca de ideias.', 'A105.jpg', TRUE),
('C316', 'Sala C316', 'Estudo em grupo', 'Bloco C', 3, 12, 'Wi-Fi • Projetor • Quadro branco • Computadores', 'Sala equipada com computadores para trabalhos práticos.', 'C316.jpg', TRUE),
('B201', 'Sala B201', 'Estudo em grupo', 'Bloco B', 2, 25, 'Wi-Fi • Quadro branco • Projetor', 'Sala ampla e bem ventilada, ideal para apresentações e reuniões.', 'B201.jpg', TRUE),
('C325', 'Sala C325', 'Estudo em grupo', 'Bloco C', 3, 50, 'Wi-Fi • Quadro branco • Projetor • Computadores', 'Sala ampla, perfeita para estudos em grupo.', 'C325.jpg', TRUE),
('E305', 'Sala E305', 'Estudo em grupo', 'Bloco E', 3, 30, 'Wi-Fi • Projetor • Quadro branco', 'Sala grande com recursos audiovisuais, adequada para palestras e workshops.', 'E305.jpg', TRUE);

-- Reservas de exemplo no próximo dia útil (relativo à data em que o script roda)
SET @proximo_dia_util = DATE_ADD(CURDATE(), INTERVAL CASE DAYOFWEEK(CURDATE()) WHEN 6 THEN 3 WHEN 7 THEN 2 ELSE 1 END DAY);
INSERT INTO reservas (codigo, sala_id, usuario_id, data, hora_inicio, hora_fim, atividade, pessoas) VALUES
('SF-DEMO-00001', 1, 1, @proximo_dia_util, '08:00', '09:30', 'Aula de Biologia', 28),
('SF-DEMO-00002', 3, 1, @proximo_dia_util, '14:00', '15:40', 'Prática de Programação', 22),
('SF-DEMO-00003', 6, 2, @proximo_dia_util, '14:00', '16:00', 'Trabalho em grupo — APS II', 5);

-- Datas bloqueadas de exemplo
INSERT INTO datas_bloqueadas (data, motivo, criado_por) VALUES
('2026-12-25', 'Natal', 1),
('2027-01-01', 'Confraternização Universal', 1);
