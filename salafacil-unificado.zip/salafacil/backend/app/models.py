from sqlalchemy import (Boolean, CheckConstraint, Column, Date, DateTime, ForeignKey, Index, Integer,
                        String, Time, func)
from sqlalchemy.orm import relationship

from .config import Base

PERFIL_ALUNO = "aluno"
PERFIL_PROFESSOR = "professor"
STATUS_CONFIRMADA = "confirmada"
STATUS_CANCELADA = "cancelada"
STATUS_CONCLUIDA = "concluida"  # calculado, nunca gravado


class Usuario(Base):
    __tablename__ = "usuarios"
    __table_args__ = (CheckConstraint("email IS NOT NULL OR matricula IS NOT NULL", name="ck_usuario_login"),)

    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=True)
    matricula = Column(String(30), unique=True, nullable=True)
    senha = Column(String(255), nullable=False)
    perfil = Column(String(20), nullable=False, default=PERFIL_ALUNO)
    cargo = Column(String(100), nullable=True)
    ativo = Column(Boolean, nullable=False, default=True)
    criado_em = Column(DateTime, nullable=False, server_default=func.now())


class Sala(Base):
    __tablename__ = "salas"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(20), unique=True, nullable=False)
    nome = Column(String(100), nullable=False)
    tipo = Column(String(50), nullable=False, default="Sala de aula")
    bloco = Column(String(50), nullable=False)
    andar = Column(Integer, nullable=False, default=0)
    campus = Column(String(100), nullable=False, default="Campus Principal")
    capacidade = Column(Integer, nullable=False)
    recursos = Column(String(255))
    descricao = Column(String(500))
    imagem = Column(String(100))
    permite_aluno = Column(Boolean, nullable=False, default=False)
    ativa = Column(Boolean, nullable=False, default=True)


class Reserva(Base):
    __tablename__ = "reservas"
    __table_args__ = (
        CheckConstraint("hora_inicio < hora_fim", name="ck_reserva_horario"),
        Index("ix_reserva_sala_data", "sala_id", "data"),
        Index("ix_reserva_usuario_data", "usuario_id", "data"),
    )

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(20), unique=True, nullable=False)
    sala_id = Column(Integer, ForeignKey("salas.id"), nullable=False)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False)
    data = Column(Date, nullable=False)
    hora_inicio = Column(Time, nullable=False)
    hora_fim = Column(Time, nullable=False)
    atividade = Column(String(200), nullable=False)
    pessoas = Column(Integer)
    status = Column(String(20), nullable=False, default=STATUS_CONFIRMADA)
    criado_em = Column(DateTime, nullable=False, server_default=func.now())
    cancelada_em = Column(DateTime)

    sala = relationship(Sala, lazy="joined")
    usuario = relationship(Usuario, lazy="joined")


class DataBloqueada(Base):
    __tablename__ = "datas_bloqueadas"

    id = Column(Integer, primary_key=True, index=True)
    data = Column(Date, unique=True, nullable=False)
    motivo = Column(String(150), nullable=False)
    criado_por = Column(Integer, ForeignKey("usuarios.id"))
    criado_em = Column(DateTime, nullable=False, server_default=func.now())
