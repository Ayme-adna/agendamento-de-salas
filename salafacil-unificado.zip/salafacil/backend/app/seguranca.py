"""Senhas (pbkdf2), token de sessão assinado (HMAC) e dependências de autenticação."""

import base64
import binascii
import hashlib
import hmac
import secrets
import time
from typing import Optional

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from . import config
from .models import PERFIL_PROFESSOR, Usuario

security = HTTPBearer(auto_error=False)
DURACAO_TOKEN = 60 * 60 * 24


def get_db():
    db = config.SessionLocal()
    try:
        yield db
    except SQLAlchemyError as exc:
        db.rollback()
        raise HTTPException(503, "Não foi possível acessar o banco de dados. Tente novamente.") from exc
    finally:
        db.close()


def hash_senha(senha: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", senha.encode(), salt.encode(), 600_000).hex()
    return f"pbkdf2_sha256${salt}${digest}"


def verificar_senha(senha: str, armazenada: str) -> bool:
    if armazenada.startswith("pbkdf2_sha256$"):
        try:
            _, salt, digest = armazenada.split("$")
        except ValueError:
            return False
        calculado = hashlib.pbkdf2_hmac("sha256", senha.encode(), salt.encode(), 600_000).hex()
        return hmac.compare_digest(calculado, digest)
    # Compatibilidade: senha antiga em texto puro (é convertida para hash no login).
    return hmac.compare_digest(senha.encode(), armazenada.encode())


def criar_token(usuario_id: int) -> str:
    payload = f"{usuario_id}:{int(time.time()) + DURACAO_TOKEN}:{secrets.token_hex(16)}"
    assinatura = hmac.new(config.SESSION_SECRET, payload.encode(), hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f"{payload}:{assinatura}".encode()).decode()


def usuario_atual(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
                  db: Session = Depends(get_db)) -> Usuario:
    try:
        if credentials is None:
            raise ValueError()
        texto = base64.urlsafe_b64decode(credentials.credentials).decode()
        usuario_id, expiracao, nonce, assinatura = texto.split(":")
        esperado = hmac.new(config.SESSION_SECRET, f"{usuario_id}:{expiracao}:{nonce}".encode(),
                            hashlib.sha256).hexdigest()
        if not hmac.compare_digest(assinatura, esperado) or int(expiracao) <= time.time():
            raise ValueError()
        usuario = db.get(Usuario, int(usuario_id))
        if usuario is None or not usuario.ativo:
            raise ValueError()
        return usuario
    except (ValueError, UnicodeError, binascii.Error):
        raise HTTPException(401, "Sua sessão expirou. Entre novamente.",
                            headers={"WWW-Authenticate": "Bearer"})


def eh_professor(usuario: Usuario) -> bool:
    return usuario.perfil == PERFIL_PROFESSOR
