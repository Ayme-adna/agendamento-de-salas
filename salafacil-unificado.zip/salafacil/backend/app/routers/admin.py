"""Administração: cadastro de salas, professores e datas bloqueadas. Somente professores."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from .. import config
from ..models import PERFIL_PROFESSOR, STATUS_CANCELADA, STATUS_CONFIRMADA, DataBloqueada, Reserva, Sala, Usuario
from ..regras import ja_comecou, sala_out
from ..schemas import (AtivoIn, DataBloqueadaIn, DataBloqueadaOut, ProfessorIn, ProfessorOut, SalaAdminOut,
                       SalaIn)
from ..seguranca import eh_professor, get_db, hash_senha, usuario_atual
from .auth import RE_EMAIL


def requer_professor(usuario: Usuario = Depends(usuario_atual)) -> Usuario:
    if not eh_professor(usuario):
        raise HTTPException(403, "Sem permissão. Esta área é exclusiva de professores.")
    return usuario


router = APIRouter(prefix="/admin", tags=["Administração"], dependencies=[Depends(requer_professor)])


def futuras(db: Session, coluna, valor) -> int:
    """Quantidade de reservas confirmadas de hoje em diante para a sala/usuário/data informado."""
    return db.query(func.count(Reserva.id)).filter(
        coluna == valor, Reserva.status == STATUS_CONFIRMADA, Reserva.data >= config.agora().date()).scalar()


# ---------------- Salas ----------------

def sala_admin_out(db: Session, sala: Sala) -> SalaAdminOut:
    base = sala_out(sala, [], config.agora())
    return SalaAdminOut(**base.model_dump(), ativa=bool(sala.ativa),
                        reservas_futuras=futuras(db, Reserva.sala_id, sala.id))


def aplicar_sala(sala: Sala, dados: SalaIn):
    sala.codigo = dados.codigo.strip().upper()
    sala.nome = dados.nome.strip()
    sala.tipo = dados.tipo.strip()
    sala.bloco = dados.bloco.strip()
    sala.andar = dados.andar
    sala.campus = dados.campus.strip()
    sala.capacidade = dados.capacidade
    sala.recursos = " • ".join(r.strip() for r in dados.recursos if r.strip()) or None
    sala.descricao = (dados.descricao or "").strip() or None
    sala.imagem = (dados.imagem or "").strip() or None
    sala.permite_aluno = dados.permite_aluno


def checar_codigo(db: Session, codigo: str, sala_id: int | None = None):
    consulta = db.query(Sala.id).filter(Sala.codigo == codigo.strip().upper())
    if sala_id:
        consulta = consulta.filter(Sala.id != sala_id)
    if consulta.first():
        raise HTTPException(409, "Já existe uma sala com esse código.")


@router.get("/salas", response_model=list[SalaAdminOut])
def listar_salas(db: Session = Depends(get_db)):
    return [sala_admin_out(db, s) for s in db.query(Sala).order_by(Sala.ativa.desc(), Sala.bloco, Sala.nome).all()]


@router.post("/salas", response_model=SalaAdminOut, status_code=201)
def criar_sala(dados: SalaIn, db: Session = Depends(get_db)):
    checar_codigo(db, dados.codigo)
    sala = Sala(ativa=True)
    aplicar_sala(sala, dados)
    db.add(sala)
    db.commit()
    db.refresh(sala)
    return sala_admin_out(db, sala)


@router.put("/salas/{sala_id}", response_model=SalaAdminOut)
def editar_sala(sala_id: int, dados: SalaIn, db: Session = Depends(get_db)):
    sala = db.get(Sala, sala_id)
    if sala is None:
        raise HTTPException(404, "Sala não encontrada.")
    checar_codigo(db, dados.codigo, sala_id)
    maior = db.query(func.max(Reserva.pessoas)).filter(
        Reserva.sala_id == sala_id, Reserva.status == STATUS_CONFIRMADA, Reserva.data >= config.agora().date()).scalar()
    if maior and dados.capacidade < maior:
        raise HTTPException(409, f"Há reserva futura com {maior} pessoas nesta sala. A capacidade não pode ficar menor que isso.")
    if not dados.permite_aluno and sala.permite_aluno:
        alunos = db.query(func.count(Reserva.id)).join(Usuario).filter(
            Reserva.sala_id == sala_id, Reserva.status == STATUS_CONFIRMADA,
            Reserva.data >= config.agora().date(), Usuario.perfil != PERFIL_PROFESSOR).scalar()
        if alunos:
            raise HTTPException(409, f"Há {alunos} reserva(s) futura(s) de alunos nesta sala. Cancele-as antes de fechá-la para alunos.")
    aplicar_sala(sala, dados)
    db.commit()
    db.refresh(sala)
    return sala_admin_out(db, sala)


@router.patch("/salas/{sala_id}/ativa", response_model=SalaAdminOut)
def ativar_sala(sala_id: int, dados: AtivoIn, db: Session = Depends(get_db)):
    sala = db.get(Sala, sala_id)
    if sala is None:
        raise HTTPException(404, "Sala não encontrada.")
    if not dados.ativo:
        total = futuras(db, Reserva.sala_id, sala_id)
        if total:
            raise HTTPException(409, f"A sala tem {total} reserva(s) futura(s). Cancele-as antes de desativar.")
    sala.ativa = dados.ativo
    db.commit()
    db.refresh(sala)
    return sala_admin_out(db, sala)


# ---------------- Professores ----------------

def professor_out(db: Session, u: Usuario) -> ProfessorOut:
    return ProfessorOut(id=u.id, nome=u.nome, email=u.email, cargo=u.cargo or "Professor(a)", ativo=bool(u.ativo),
                        reservas_futuras=futuras(db, Reserva.usuario_id, u.id))


@router.get("/professores", response_model=list[ProfessorOut])
def listar_professores(db: Session = Depends(get_db)):
    lista = db.query(Usuario).filter(Usuario.perfil == PERFIL_PROFESSOR).order_by(Usuario.ativo.desc(), Usuario.nome).all()
    return [professor_out(db, u) for u in lista]


@router.post("/professores", response_model=ProfessorOut, status_code=201)
def criar_professor(dados: ProfessorIn, db: Session = Depends(get_db)):
    email = dados.email.strip().lower()
    if not RE_EMAIL.match(email):
        raise HTTPException(422, "Informe um e-mail válido.")
    if db.query(Usuario.id).filter(or_(Usuario.email == email, Usuario.matricula == email)).first():
        raise HTTPException(409, "Já existe um usuário com esse e-mail.")
    novo = Usuario(nome=dados.nome.strip(), email=email, senha=hash_senha(dados.senha), perfil=PERFIL_PROFESSOR,
                   cargo=(dados.cargo or "").strip() or None, ativo=True)
    db.add(novo)
    db.commit()
    db.refresh(novo)
    return professor_out(db, novo)


@router.patch("/professores/{usuario_id}/ativo", response_model=ProfessorOut)
def ativar_professor(usuario_id: int, dados: AtivoIn, db: Session = Depends(get_db),
                     eu: Usuario = Depends(requer_professor)):
    prof = db.query(Usuario).filter(Usuario.id == usuario_id, Usuario.perfil == PERFIL_PROFESSOR).first()
    if prof is None:
        raise HTTPException(404, "Professor não encontrado.")
    if prof.id == eu.id and not dados.ativo:
        raise HTTPException(422, "Você não pode desativar o seu próprio acesso.")
    canceladas = 0
    if not dados.ativo:
        # Libera as salas: cancela as reservas do professor que ainda não começaram.
        momento = config.agora()
        pendentes = db.query(Reserva).filter(Reserva.usuario_id == prof.id, Reserva.status == STATUS_CONFIRMADA,
                                             Reserva.data >= momento.date()).all()
        for r in pendentes:
            if not ja_comecou(r.data, r.hora_inicio, momento):
                r.status = STATUS_CANCELADA
                r.cancelada_em = momento.replace(tzinfo=None)
                canceladas += 1
    prof.ativo = dados.ativo
    db.commit()
    db.refresh(prof)
    return professor_out(db, prof).model_copy(update={"reservas_canceladas": canceladas})


# ---------------- Datas bloqueadas ----------------

@router.get("/datas-bloqueadas", response_model=list[DataBloqueadaOut])
def listar_datas(db: Session = Depends(get_db)):
    return [DataBloqueadaOut(id=d.id, data=d.data, motivo=d.motivo)
            for d in db.query(DataBloqueada).order_by(DataBloqueada.data).all()]


@router.post("/datas-bloqueadas", response_model=DataBloqueadaOut, status_code=201)
def bloquear_data(dados: DataBloqueadaIn, db: Session = Depends(get_db), eu: Usuario = Depends(requer_professor)):
    if dados.data < config.agora().date():
        raise HTTPException(422, "Escolha uma data de hoje em diante.")
    if db.query(DataBloqueada.id).filter(DataBloqueada.data == dados.data).first():
        raise HTTPException(409, "Essa data já está bloqueada.")
    total = futuras(db, Reserva.data, dados.data)
    if total:
        raise HTTPException(409, f"Há {total} reserva(s) confirmada(s) nessa data. Cancele-as antes de bloquear.")
    nova = DataBloqueada(data=dados.data, motivo=dados.motivo.strip(), criado_por=eu.id)
    db.add(nova)
    db.commit()
    db.refresh(nova)
    return DataBloqueadaOut(id=nova.id, data=nova.data, motivo=nova.motivo)


@router.delete("/datas-bloqueadas/{bloqueio_id}", status_code=204)
def desbloquear_data(bloqueio_id: int, db: Session = Depends(get_db)):
    bloqueio = db.get(DataBloqueada, bloqueio_id)
    if bloqueio is None:
        raise HTTPException(404, "Data não encontrada.")
    db.delete(bloqueio)
    db.commit()
