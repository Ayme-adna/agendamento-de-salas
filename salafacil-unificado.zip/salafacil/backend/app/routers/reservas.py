import secrets

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session

from .. import config
from ..models import STATUS_CANCELADA, STATUS_CONFIRMADA, Reserva, Sala, Usuario
from ..regras import hhmm, ja_comecou, minutos, problema_funcionamento, reserva_out, sobrepoe
from ..schemas import ReservaIn, ReservaOut
from ..seguranca import eh_professor, get_db, usuario_atual

router = APIRouter(prefix="/reservas", tags=["Reservas"])


def gerar_codigo(db: Session, ano: int) -> str:
    while True:
        codigo = f"SF-{ano}-{secrets.randbelow(90000) + 10000}"
        if not db.query(Reserva.id).filter(Reserva.codigo == codigo).first():
            return codigo


@router.get("", response_model=list[ReservaOut])
def listar_reservas(db: Session = Depends(get_db), usuario: Usuario = Depends(usuario_atual)):
    """Professor: agenda geral (todas as reservas ativas + as próprias canceladas).
    Aluno: somente as próprias reservas."""
    consulta = db.query(Reserva)
    if eh_professor(usuario):
        consulta = consulta.filter(or_(Reserva.status != STATUS_CANCELADA, Reserva.usuario_id == usuario.id))
    else:
        consulta = consulta.filter(Reserva.usuario_id == usuario.id)
    momento = config.agora()
    return [reserva_out(r, usuario, momento)
            for r in consulta.order_by(Reserva.data, Reserva.hora_inicio).all()]


@router.get("/codigo/{codigo}", response_model=ReservaOut)
def comprovante(codigo: str, db: Session = Depends(get_db), usuario: Usuario = Depends(usuario_atual)):
    reserva = db.query(Reserva).filter(Reserva.codigo == codigo, Reserva.usuario_id == usuario.id).first()
    if reserva is None:
        raise HTTPException(404, "Reserva não encontrada.")
    return reserva_out(reserva, usuario)


@router.post("", response_model=ReservaOut, status_code=201)
def criar_reserva(dados: ReservaIn, db: Session = Depends(get_db), usuario: Usuario = Depends(usuario_atual)):
    professor = eh_professor(usuario)
    atividade = dados.atividade.strip()
    if not atividade:
        raise HTTPException(422, "Informe a atividade ou finalidade da reserva.")
    inicio, fim = minutos(dados.hora_inicio), minutos(dados.hora_fim)
    if inicio >= fim:
        raise HTTPException(422, "Informe um horário válido, com o término após o início.")
    momento = config.agora()
    if ja_comecou(dados.data, dados.hora_inicio, momento):
        raise HTTPException(422, "Escolha uma data e um horário futuros.")
    problema = problema_funcionamento(db, dados.data, inicio, fim)
    if problema:
        raise HTTPException(422, problema)

    # Trava o usuário e depois a sala: dois pedidos simultâneos da mesma pessoa (ou para a
    # mesma sala) são processados um de cada vez, então as checagens abaixo não podem ser burladas.
    db.query(Usuario).filter(Usuario.id == usuario.id).with_for_update().first()
    sala = db.query(Sala).filter(Sala.id == dados.sala_id, Sala.ativa.is_(True)).with_for_update().first()
    if sala is None:
        raise HTTPException(404, "Sala não encontrada.")

    # Uma sala por pessoa no mesmo horário (vale para aluno e professor).
    minhas = db.query(Reserva).filter(Reserva.usuario_id == usuario.id, Reserva.data == dados.data,
                                      Reserva.status == STATUS_CONFIRMADA).all()
    propria = next((r for r in minhas if sobrepoe(inicio, fim, minutos(r.hora_inicio), minutos(r.hora_fim))), None)
    if propria:
        raise HTTPException(409, f"Você já tem uma reserva nesse horário ({propria.sala.nome}, "
                                 f"{hhmm(propria.hora_inicio)}–{hhmm(propria.hora_fim)}).")

    if not professor:
        if not sala.permite_aluno:
            raise HTTPException(403, "Esta sala é de uso exclusivo de professores.")
        if (hhmm(inicio), hhmm(fim)) not in config.BLOCOS_ALUNO:
            blocos = ", ".join(f"{i}–{f}" for i, f in config.BLOCOS_ALUNO)
            raise HTTPException(422, f"Alunos reservam em períodos fixos de 2 horas: {blocos}.")
        if not dados.pessoas:
            raise HTTPException(422, "Informe quantas pessoas vão usar a sala.")
        usados = sum(minutos(r.hora_fim) - minutos(r.hora_inicio) for r in minhas)
        if usados + (fim - inicio) > config.LIMITE_DIARIO_ALUNO_MIN:
            raise HTTPException(409, f"Você pode reservar até {config.LIMITE_DIARIO_ALUNO_MIN // 60} horas por dia.")

    if dados.pessoas and dados.pessoas > sala.capacidade:
        raise HTTPException(422, f"A sala comporta até {sala.capacidade} pessoas.")

    ocupadas = db.query(Reserva).filter(Reserva.sala_id == sala.id, Reserva.data == dados.data,
                                        Reserva.status == STATUS_CONFIRMADA).with_for_update().all()
    if any(sobrepoe(inicio, fim, minutos(r.hora_inicio), minutos(r.hora_fim)) for r in ocupadas):
        raise HTTPException(409, "Esta sala já está reservada nesse horário. Escolha outro período.")

    nova = Reserva(codigo=gerar_codigo(db, dados.data.year), sala_id=sala.id, usuario_id=usuario.id,
                   data=dados.data, hora_inicio=dados.hora_inicio.replace(second=0, microsecond=0),
                   hora_fim=dados.hora_fim.replace(second=0, microsecond=0), atividade=atividade,
                   pessoas=dados.pessoas, status=STATUS_CONFIRMADA)
    db.add(nova)
    db.commit()
    db.refresh(nova)
    return reserva_out(nova, usuario, momento)


@router.patch("/{reserva_id}/cancelar", response_model=ReservaOut)
def cancelar_reserva(reserva_id: int, db: Session = Depends(get_db), usuario: Usuario = Depends(usuario_atual)):
    """Cada usuário cancela apenas as próprias reservas, antes do horário de início."""
    reserva = db.query(Reserva).filter(Reserva.id == reserva_id, Reserva.usuario_id == usuario.id).first()
    if reserva is None:
        raise HTTPException(404, "Reserva não encontrada.")
    if reserva.status == STATUS_CANCELADA:
        raise HTTPException(409, "Esta reserva já foi cancelada.")
    momento = config.agora()
    if ja_comecou(reserva.data, reserva.hora_inicio, momento):
        raise HTTPException(409, "Não é possível cancelar uma reserva que já começou.")
    reserva.status = STATUS_CANCELADA
    reserva.cancelada_em = momento.replace(tzinfo=None)
    db.commit()
    db.refresh(reserva)
    return reserva_out(reserva, usuario, momento)
