import re

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..models import PERFIL_ALUNO, Usuario
from ..schemas import CadastroIn, LoginIn, SessaoOut, UsuarioOut
from ..seguranca import criar_token, get_db, hash_senha, usuario_atual, verificar_senha

router = APIRouter(prefix="/auth", tags=["Autenticação"])

RE_MATRICULA = re.compile(r"^\d{6,}$")
RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def usuario_out(u: Usuario) -> UsuarioOut:
    cargo = u.cargo or ("Estudante" if u.perfil == PERFIL_ALUNO else "Professor(a)")
    return UsuarioOut(id=u.id, nome=u.nome, email=u.email, matricula=u.matricula, perfil=u.perfil, cargo=cargo)


@router.post("/login", response_model=SessaoOut)
def login(dados: LoginIn, db: Session = Depends(get_db)):
    login = dados.login.strip().lower()
    usuario = db.query(Usuario).filter(or_(Usuario.email == login, Usuario.matricula == login)).first()
    if usuario is None or not usuario.ativo or not verificar_senha(dados.senha, usuario.senha):
        raise HTTPException(401, "E-mail/matrícula ou senha incorretos.")
    if not usuario.senha.startswith("pbkdf2_sha256$"):
        usuario.senha = hash_senha(dados.senha)
        db.commit()
    return SessaoOut(access_token=criar_token(usuario.id), usuario=usuario_out(usuario))


@router.post("/cadastro", response_model=SessaoOut, status_code=201)
def cadastro(dados: CadastroIn, db: Session = Depends(get_db)):
    """Autocadastro: sempre cria um ALUNO. Professores são cadastrados pela instituição."""
    nome = dados.nome.strip()
    login = dados.login.strip().lower()
    if len(nome) < 3:
        raise HTTPException(422, "Informe seu nome completo.")
    eh_matricula = bool(RE_MATRICULA.match(login))
    if not eh_matricula and not RE_EMAIL.match(login):
        raise HTTPException(422, "Use sua matrícula (só números, mínimo 6) ou seu e-mail institucional.")
    existe = db.query(Usuario).filter(or_(Usuario.email == login, Usuario.matricula == login)).first()
    if existe:
        raise HTTPException(409, "Já existe cadastro com essa matrícula/e-mail.")
    usuario = Usuario(nome=nome, senha=hash_senha(dados.senha), perfil=PERFIL_ALUNO, cargo="Estudante",
                      matricula=login if eh_matricula else None, email=None if eh_matricula else login)
    db.add(usuario)
    db.commit()
    db.refresh(usuario)
    return SessaoOut(access_token=criar_token(usuario.id), usuario=usuario_out(usuario))


@router.get("/me", response_model=UsuarioOut)
def perfil(usuario: Usuario = Depends(usuario_atual)):
    return usuario_out(usuario)
