"""Testes isolados em SQLite em memória; não acessam o MySQL da aplicação.
Rode na pasta backend: python -m unittest discover -s tests -v"""

import os
import unittest
from datetime import datetime
from unittest.mock import patch

os.environ["DATABASE_URL"] = "sqlite://"

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app import config, seguranca
from app.main import app
from app.models import Reserva, Sala, Usuario

AGORA = datetime(2030, 8, 14, 9, 0, tzinfo=config.TIMEZONE)  # quarta-feira, 09:00
HOJE, AMANHA = "2030-08-14", "2030-08-15"


class Base(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
        config.Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

        def db_teste():
            db = self.Session()
            try:
                yield db
            finally:
                db.close()

        app.dependency_overrides[seguranca.get_db] = db_teste
        db = self.Session()
        senha = seguranca.hash_senha("123456")
        db.add_all([
            Usuario(nome="Carla Furtado", email="carla@escola.edu.br", senha=senha, perfil="professor"),
            Usuario(nome="Bruno Lima", email="bruno@escola.edu.br", senha=senha, perfil="professor"),
            Usuario(nome="Lucas Andrade", matricula="2026001", senha=senha, perfil="aluno"),
            Usuario(nome="Maria Souza", matricula="2026002", senha=senha, perfil="aluno"),
            Sala(codigo="A101", nome="Sala 101", bloco="Bloco A", capacidade=30, permite_aluno=False),
            Sala(codigo="C217", nome="Sala C217", bloco="Bloco C", capacidade=20, permite_aluno=True,
                 recursos="Wi-Fi • Projetor", imagem="C217.jpg"),
            Sala(codigo="A105", nome="Sala A105", bloco="Bloco A", capacidade=15, permite_aluno=True),
        ])
        db.commit()
        db.close()
        self.relogio = patch.object(config, "agora", return_value=AGORA)
        self.relogio.start()
        self.client = TestClient(app)
        self.prof = self.entrar("carla@escola.edu.br")
        self.aluno = self.entrar("2026001")

    def tearDown(self):
        self.relogio.stop()
        app.dependency_overrides.clear()
        self.engine.dispose()

    def entrar(self, login, senha="123456"):
        r = self.client.post("/auth/login", json={"login": login, "senha": senha})
        self.assertEqual(r.status_code, 200, r.text)
        return {"Authorization": f"Bearer {r.json()['access_token']}"}

    def reservar(self, quem, sala_id=1, data=HOJE, inicio="10:00", fim="11:30", atividade="Aula", pessoas=None):
        corpo = {"sala_id": sala_id, "data": data, "hora_inicio": inicio, "hora_fim": fim, "atividade": atividade}
        if pessoas is not None:
            corpo["pessoas"] = pessoas
        return self.client.post("/reservas", json=corpo, headers=quem)


class AutenticacaoTests(Base):
    def test_login_por_email_ou_matricula_e_perfil(self):
        me = self.client.get("/auth/me", headers=self.aluno).json()
        self.assertEqual((me["perfil"], me["matricula"], me["cargo"]), ("aluno", "2026001", "Estudante"))
        self.assertEqual(self.client.get("/auth/me", headers=self.prof).json()["perfil"], "professor")

    def test_login_invalido(self):
        for login, senha in [("carla@escola.edu.br", "errada"), ("naoexiste@x.com", "123456")]:
            r = self.client.post("/auth/login", json={"login": login, "senha": senha})
            self.assertEqual(r.status_code, 401)

    def test_cadastro_cria_sempre_aluno_e_ja_entra(self):
        r = self.client.post("/auth/cadastro", json={"nome": "Ana Costa", "login": "ANA@ALUNO.EDU.BR", "senha": "abcdef"})
        self.assertEqual(r.status_code, 201, r.text)
        self.assertEqual(r.json()["usuario"]["perfil"], "aluno")
        self.assertEqual(r.json()["usuario"]["email"], "ana@aluno.edu.br")
        self.entrar("ana@aluno.edu.br", "abcdef")

    def test_cadastro_valida_login_senha_e_duplicidade(self):
        casos = [({"nome": "Ana", "login": "123", "senha": "abcdef"}, 422),
                 ({"nome": "Ana Costa", "login": "2026009", "senha": "123"}, 422),
                 ({"nome": "Outro", "login": "2026001", "senha": "abcdef"}, 409)]
        for corpo, codigo in casos:
            self.assertEqual(self.client.post("/auth/cadastro", json=corpo).status_code, codigo, corpo)

    def test_migra_senha_em_texto_puro(self):
        db = self.Session()
        db.add(Usuario(nome="Legado", email="legado@escola.edu.br", senha="antiga", perfil="professor"))
        db.commit()
        self.entrar("legado@escola.edu.br", "antiga")
        self.assertTrue(db.query(Usuario).filter_by(email="legado@escola.edu.br").one().senha.startswith("pbkdf2"))
        db.close()

    def test_token_invalido_ou_ausente(self):
        self.assertEqual(self.client.get("/auth/me").status_code, 401)
        self.assertEqual(self.client.get("/auth/me", headers={"Authorization": "Bearer xyz"}).status_code, 401)
        token = self.prof["Authorization"][:-4] + "AAAA"
        self.assertEqual(self.client.get("/auth/me", headers={"Authorization": token}).status_code, 401)


class SalasTests(Base):
    def test_aluno_ve_so_salas_liberadas(self):
        self.assertEqual(len(self.client.get("/salas", headers=self.prof).json()), 3)
        salas = self.client.get("/salas", headers=self.aluno).json()
        self.assertEqual({s["codigo"] for s in salas}, {"C217", "A105"})
        self.assertEqual(salas[1]["recursos"], ["Wi-Fi", "Projetor"])
        self.assertEqual(self.client.get("/salas/1", headers=self.aluno).status_code, 404)

    def test_filtros_de_busca_e_disponibilidade_no_periodo(self):
        self.reservar(self.aluno, sala_id=2, data=AMANHA, inicio="14:00", fim="16:00", pessoas=4)
        r = self.client.get("/salas", headers=self.aluno,
                            params={"data": AMANHA, "inicio": "14:00", "fim": "16:00", "pessoas": 16}).json()
        self.assertEqual([(s["codigo"], s["disponivel_periodo"]) for s in r], [("C217", False)])
        passado = self.client.get("/salas", headers=self.aluno, params={"data": HOJE, "inicio": "08:00", "fim": "10:00"}).json()
        self.assertTrue(all(s["disponivel_periodo"] is False for s in passado))
        r = self.client.get("/salas", headers=self.prof, params={"busca": "projetor"}).json()
        self.assertEqual([s["codigo"] for s in r], ["C217"])
        d = self.client.get("/salas/2/disponibilidade", headers=self.prof, params={"data": AMANHA}).json()
        self.assertEqual(d["ocupados"], [{"inicio": "14:00", "fim": "16:00"}])

    def test_status_agora(self):
        self.reservar(self.prof)
        self.assertEqual(self.client.get("/salas/1", headers=self.prof).json()["detalhe_status"], "Livre até 10:00")
        with patch.object(config, "agora", return_value=AGORA.replace(hour=10, minute=15)):
            sala = self.client.get("/salas/1", headers=self.prof).json()
            self.assertEqual((sala["status"], sala["detalhe_status"]), ("Ocupada", "Ocupada até 11:30"))

    def test_regras_publicas(self):
        r = self.client.get("/regras").json()
        self.assertEqual(r["limite_diario_aluno_min"], 120)
        self.assertIn({"inicio": "14:00", "fim": "16:00"}, r["blocos_aluno"])


class ReservaProfessorTests(Base):
    def test_cria_com_intervalo_livre_e_gera_codigo(self):
        r = self.reservar(self.prof, atividade="  Aula de Biologia  ")
        self.assertEqual(r.status_code, 201, r.text)
        corpo = r.json()
        self.assertEqual((corpo["atividade"], corpo["hora_inicio"], corpo["hora_fim"]), ("Aula de Biologia", "10:00", "11:30"))
        self.assertTrue(corpo["codigo"].startswith("SF-2030-"))
        self.assertEqual((corpo["responsavel"], corpo["perfil_responsavel"], corpo["status"]), ("Carla Furtado", "professor", "confirmada"))
        self.assertTrue(corpo["pode_cancelar"])

    def test_rejeita_sobreposicao_aceita_adjacentes(self):
        self.assertEqual(self.reservar(self.prof).status_code, 201)
        for inicio, fim in [("10:00", "11:30"), ("09:30", "10:30"), ("11:00", "12:00"), ("10:30", "11:00")]:
            self.assertEqual(self.reservar(self.prof, inicio=inicio, fim=fim).status_code, 409)
        self.assertEqual(self.reservar(self.prof, inicio="11:30", fim="12:00").status_code, 201)
        self.assertEqual(self.reservar(self.prof, data=AMANHA).status_code, 201)

    def test_rejeita_passado_horario_invalido_capacidade_e_sala_inexistente(self):
        self.assertEqual(self.reservar(self.prof, data="2030-08-13").status_code, 422)
        self.assertEqual(self.reservar(self.prof, inicio="09:00", fim="10:00").status_code, 422)
        self.assertEqual(self.reservar(self.prof, inicio="11:00", fim="10:00").status_code, 422)
        self.assertEqual(self.reservar(self.prof, inicio="25:00", fim="26:00").status_code, 422)
        self.assertEqual(self.reservar(self.prof, pessoas=31).status_code, 422)
        self.assertEqual(self.reservar(self.prof, atividade="   ").status_code, 422)
        self.assertEqual(self.reservar(self.prof, sala_id=99).status_code, 404)

    def test_agenda_geral_mostra_alunos_e_esconde_cancelamentos_alheios(self):
        self.reservar(self.aluno, sala_id=2, inicio="14:00", fim="16:00", pessoas=3)
        cancelada = self.reservar(self.aluno, sala_id=3, data=AMANHA, inicio="10:00", fim="12:00", pessoas=3).json()
        self.client.patch(f"/reservas/{cancelada['id']}/cancelar", headers=self.aluno)
        self.reservar(self.prof)
        agenda = self.client.get("/reservas", headers=self.prof).json()
        self.assertEqual(len(agenda), 2)
        aluno = next(a for a in agenda if a["perfil_responsavel"] == "aluno")
        self.assertFalse(aluno["pode_cancelar"])

    def test_professor_nao_cancela_reserva_de_outro(self):
        r = self.reservar(self.entrar("bruno@escola.edu.br")).json()
        self.assertEqual(self.client.patch(f"/reservas/{r['id']}/cancelar", headers=self.prof).status_code, 404)


class ReservaAlunoTests(Base):
    def test_fluxo_completo_reservar_comprovante_cancelar(self):
        r = self.reservar(self.aluno, sala_id=2, data=AMANHA, inicio="14:00", fim="16:00",
                          atividade="Trabalho em grupo", pessoas=5)
        self.assertEqual(r.status_code, 201, r.text)
        codigo = r.json()["codigo"]
        self.assertEqual(self.client.get(f"/reservas/codigo/{codigo}", headers=self.aluno).json()["pessoas"], 5)
        self.assertEqual(self.client.get(f"/reservas/codigo/{codigo}", headers=self.prof).status_code, 404)
        c = self.client.patch(f"/reservas/{r.json()['id']}/cancelar", headers=self.aluno)
        self.assertEqual(c.json()["status"], "cancelada")
        self.assertEqual(self.client.patch(f"/reservas/{r.json()['id']}/cancelar", headers=self.aluno).status_code, 409)
        # Após cancelar, o horário fica livre de novo.
        self.assertEqual(self.reservar(self.aluno, sala_id=2, data=AMANHA, inicio="14:00", fim="16:00", pessoas=2).status_code, 201)

    def test_aluno_ve_so_as_proprias(self):
        self.reservar(self.prof)
        self.reservar(self.entrar("2026002"), sala_id=2, inicio="14:00", fim="16:00", pessoas=2)
        self.assertEqual(self.client.get("/reservas", headers=self.aluno).json(), [])

    def test_regras_do_aluno(self):
        self.assertEqual(self.reservar(self.aluno, sala_id=1, inicio="10:00", fim="12:00", pessoas=2).status_code, 403)
        self.assertEqual(self.reservar(self.aluno, sala_id=2, inicio="10:00", fim="11:30", pessoas=2).status_code, 422)
        self.assertEqual(self.reservar(self.aluno, sala_id=2, inicio="10:00", fim="12:00").status_code, 422)
        self.assertEqual(self.reservar(self.aluno, sala_id=2, inicio="10:00", fim="12:00", pessoas=21).status_code, 422)

    def test_limite_de_duas_horas_por_dia(self):
        self.assertEqual(self.reservar(self.aluno, sala_id=2, inicio="10:00", fim="12:00", pessoas=2).status_code, 201)
        r = self.reservar(self.aluno, sala_id=3, inicio="14:00", fim="16:00", pessoas=2)
        self.assertEqual(r.status_code, 409)
        self.assertIn("2 horas", r.json()["detail"])
        self.assertEqual(self.reservar(self.aluno, sala_id=3, data=AMANHA, inicio="14:00", fim="16:00", pessoas=2).status_code, 201)

    def test_conflito_entre_professor_e_aluno(self):
        self.assertEqual(self.reservar(self.prof, sala_id=2, inicio="14:30", fim="15:00").status_code, 201)
        self.assertEqual(self.reservar(self.aluno, sala_id=2, inicio="14:00", fim="16:00", pessoas=2).status_code, 409)

    def test_status_concluida_e_nao_cancela_depois_de_comecar(self):
        r = self.reservar(self.aluno, sala_id=2, inicio="10:00", fim="12:00", pessoas=2).json()
        with patch.object(config, "agora", return_value=AGORA.replace(hour=10, minute=30)):
            self.assertEqual(self.client.patch(f"/reservas/{r['id']}/cancelar", headers=self.aluno).status_code, 409)
        with patch.object(config, "agora", return_value=AGORA.replace(hour=12)):
            self.assertEqual(self.client.get("/reservas", headers=self.aluno).json()[0]["status"], "concluida")


SABADO, DOMINGO = "2030-08-17", "2030-08-18"


class UmaSalaPorPessoaTests(Base):
    def test_professor_nao_pega_duas_salas_no_mesmo_horario(self):
        self.assertEqual(self.reservar(self.prof, sala_id=1, inicio="14:00", fim="15:40").status_code, 201)
        r = self.reservar(self.prof, sala_id=2, inicio="15:00", fim="16:00")
        self.assertEqual(r.status_code, 409)
        self.assertIn("Você já tem uma reserva nesse horário (Sala 101", r.json()["detail"])
        self.assertEqual(self.reservar(self.prof, sala_id=2, inicio="15:40", fim="17:00").status_code, 201)

    def test_aluno_nao_pega_duas_salas_no_mesmo_horario(self):
        self.reservar(self.aluno, sala_id=2, inicio="14:00", fim="16:00", pessoas=2)
        r = self.reservar(self.aluno, sala_id=3, inicio="14:00", fim="16:00", pessoas=2)
        self.assertEqual(r.status_code, 409)
        self.assertIn("Você já tem uma reserva nesse horário", r.json()["detail"])

    def test_reserva_cancelada_libera_a_pessoa(self):
        r = self.reservar(self.prof, sala_id=1).json()
        self.client.patch(f"/reservas/{r['id']}/cancelar", headers=self.prof)
        self.assertEqual(self.reservar(self.prof, sala_id=2).status_code, 201)


class FuncionamentoTests(Base):
    def test_domingo_fechado(self):
        r = self.reservar(self.prof, data=DOMINGO)
        self.assertEqual(r.status_code, 422)
        self.assertIn("aos domingos", r.json()["detail"])

    def test_sabado_so_de_manha(self):
        self.assertEqual(self.reservar(self.prof, data=SABADO, inicio="08:00", fim="11:00").status_code, 201)
        r = self.reservar(self.prof, sala_id=2, data=SABADO, inicio="11:00", fim="13:00")
        self.assertEqual(r.status_code, 422)
        self.assertIn("Aos sábados, as reservas devem ficar entre 07:00 e 12:00", r.json()["detail"])
        self.assertEqual(self.reservar(self.aluno, sala_id=2, data=SABADO, inicio="10:00", fim="12:00", pessoas=2).status_code, 201)
        self.assertEqual(self.reservar(self.aluno, sala_id=3, data=SABADO, inicio="12:00", fim="14:00", pessoas=2).status_code, 422)

    def test_dia_util_entre_7_e_22(self):
        self.assertEqual(self.reservar(self.prof, inicio="21:00", fim="22:30").status_code, 422)
        self.assertEqual(self.reservar(self.prof, data=AMANHA, inicio="06:30", fim="08:00").status_code, 422)
        self.assertEqual(self.reservar(self.prof, inicio="20:30", fim="22:00").status_code, 201)

    def test_data_bloqueada_e_busca(self):
        r = self.client.post("/admin/datas-bloqueadas", json={"data": AMANHA, "motivo": "Feriado municipal"}, headers=self.prof)
        self.assertEqual(r.status_code, 201, r.text)
        r = self.reservar(self.prof, data=AMANHA)
        self.assertEqual(r.status_code, 422)
        self.assertIn("Feriado municipal", r.json()["detail"])
        salas = self.client.get("/salas", headers=self.aluno, params={"data": AMANHA, "inicio": "10:00", "fim": "12:00"}).json()
        self.assertTrue(all(s["disponivel_periodo"] is False for s in salas))
        regras = self.client.get("/regras").json()
        self.assertEqual(regras["datas_bloqueadas"][0]["motivo"], "Feriado municipal")
        self.assertEqual(len(regras["funcionamento"]), 6)


class AdminTests(Base):
    SALA = {"codigo": "d101", "nome": "Sala D101", "tipo": "Sala de aula", "bloco": "Bloco D", "andar": 1,
            "capacidade": 35, "recursos": ["Wi-Fi", " Projetor "], "permite_aluno": True}

    def test_aluno_nao_acessa_admin(self):
        for metodo, rota in [("get", "/admin/salas"), ("get", "/admin/professores"), ("get", "/admin/datas-bloqueadas")]:
            self.assertEqual(getattr(self.client, metodo)(rota, headers=self.aluno).status_code, 403)
        self.assertEqual(self.client.post("/admin/salas", json=self.SALA, headers=self.aluno).status_code, 403)

    def test_cadastrar_editar_e_desativar_sala(self):
        r = self.client.post("/admin/salas", json=self.SALA, headers=self.prof)
        self.assertEqual(r.status_code, 201, r.text)
        sala = r.json()
        self.assertEqual((sala["codigo"], sala["recursos"], sala["ativa"]), ("D101", ["Wi-Fi", "Projetor"], True))
        self.assertEqual(self.client.post("/admin/salas", json=self.SALA, headers=self.prof).status_code, 409)
        self.assertIn("D101", [s["codigo"] for s in self.client.get("/salas", headers=self.aluno).json()])

        editada = self.client.put(f"/admin/salas/{sala['id']}", json={**self.SALA, "capacidade": 40}, headers=self.prof)
        self.assertEqual(editada.json()["capacidade"], 40)

        reserva = self.reservar(self.prof, sala_id=sala["id"], pessoas=30).json()
        self.assertEqual(self.client.put(f"/admin/salas/{sala['id']}", json={**self.SALA, "capacidade": 20}, headers=self.prof).status_code, 409)
        r = self.client.patch(f"/admin/salas/{sala['id']}/ativa", json={"ativo": False}, headers=self.prof)
        self.assertEqual(r.status_code, 409)
        self.client.patch(f"/reservas/{reserva['id']}/cancelar", headers=self.prof)
        r = self.client.patch(f"/admin/salas/{sala['id']}/ativa", json={"ativo": False}, headers=self.prof)
        self.assertFalse(r.json()["ativa"])
        self.assertNotIn("D101", [s["codigo"] for s in self.client.get("/salas", headers=self.prof).json()])
        self.assertEqual(self.reservar(self.prof, sala_id=sala["id"]).status_code, 404)

    def test_nao_fecha_para_alunos_com_reserva_de_aluno(self):
        self.reservar(self.aluno, sala_id=2, data=AMANHA, inicio="10:00", fim="12:00", pessoas=2)
        dados = {"codigo": "C217", "nome": "Sala C217", "tipo": "Estudo em grupo", "bloco": "Bloco C", "andar": 2,
                 "capacidade": 20, "permite_aluno": False}
        self.assertEqual(self.client.put("/admin/salas/2", json=dados, headers=self.prof).status_code, 409)

    def test_cadastrar_e_desativar_professor(self):
        r = self.client.post("/admin/professores", json={"nome": "João Pereira", "email": "Joao@Escola.edu.br",
                                                         "cargo": "Professor de Física", "senha": "abc123"}, headers=self.prof)
        self.assertEqual(r.status_code, 201, r.text)
        novo = r.json()
        token = self.entrar("joao@escola.edu.br", "abc123")
        self.assertEqual(self.client.get("/auth/me", headers=token).json()["perfil"], "professor")
        self.assertEqual(self.client.post("/admin/professores", json={"nome": "Outro", "email": "joao@escola.edu.br",
                                                                      "senha": "abc123"}, headers=self.prof).status_code, 409)
        self.client.patch(f"/admin/professores/{novo['id']}/ativo", json={"ativo": False}, headers=self.prof)
        self.assertEqual(self.client.post("/auth/login", json={"login": "joao@escola.edu.br", "senha": "abc123"}).status_code, 401)
        self.assertEqual(self.client.get("/auth/me", headers=token).status_code, 401)

    def test_desativar_professor_cancela_reservas_futuras(self):
        bruno = self.entrar("bruno@escola.edu.br")
        andamento = self.reservar(bruno, sala_id=1, inicio="10:00", fim="11:00").json()
        futura = self.reservar(bruno, sala_id=1, data=AMANHA).json()
        with patch.object(config, "agora", return_value=AGORA.replace(hour=10, minute=30)):
            r = self.client.patch("/admin/professores/2/ativo", json={"ativo": False}, headers=self.prof).json()
            self.assertEqual((r["ativo"], r["reservas_canceladas"]), (False, 1))
            agenda = {x["id"]: x["status"] for x in self.client.get("/reservas", headers=self.prof).json()}
        self.assertEqual(agenda.get(andamento["id"]), "confirmada")  # aula em andamento é mantida
        self.assertNotIn(futura["id"], agenda)                        # futura foi cancelada (sala liberada)
        self.assertEqual(self.reservar(self.prof, sala_id=1, data=AMANHA).status_code, 201)

    def test_professor_nao_desativa_a_si_mesmo(self):
        eu = self.client.get("/auth/me", headers=self.prof).json()
        self.assertEqual(self.client.patch(f"/admin/professores/{eu['id']}/ativo", json={"ativo": False}, headers=self.prof).status_code, 422)

    def test_datas_bloqueadas(self):
        self.assertEqual(self.client.post("/admin/datas-bloqueadas", json={"data": "2030-08-01", "motivo": "Passado"}, headers=self.prof).status_code, 422)
        self.reservar(self.prof, data=AMANHA)
        self.assertEqual(self.client.post("/admin/datas-bloqueadas", json={"data": AMANHA, "motivo": "Recesso"}, headers=self.prof).status_code, 409)
        r = self.client.post("/admin/datas-bloqueadas", json={"data": "2030-09-07", "motivo": "Independência"}, headers=self.prof).json()
        self.assertEqual(self.client.post("/admin/datas-bloqueadas", json={"data": "2030-09-07", "motivo": "x x"}, headers=self.prof).status_code, 409)
        self.assertEqual(self.client.delete(f"/admin/datas-bloqueadas/{r['id']}", headers=self.prof).status_code, 204)
        self.assertEqual(self.client.get("/admin/datas-bloqueadas", headers=self.prof).json(), [])


if __name__ == "__main__":
    unittest.main()
