"""Testes de concorrência contra um MySQL de verdade (no SQLite o SELECT ... FOR UPDATE não tem efeito).

Só rodam se a variável SALAFACIL_TEST_MYSQL_URL apontar para um banco VAZIO, criado só para isso
(as tabelas são criadas e apagadas a cada teste). Exemplo, no PowerShell:

    # no MySQL: CREATE DATABASE salafacil_teste;
    $env:SALAFACIL_TEST_MYSQL_URL = "mysql+mysqlconnector://root:@localhost:3306/salafacil_teste"
    .\\.venv\\Scripts\\python.exe -m unittest tests.test_concorrencia_mysql -v
"""

import os
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from unittest.mock import patch

URL = os.getenv("SALAFACIL_TEST_MYSQL_URL")
os.environ.setdefault("DATABASE_URL", "sqlite://")

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import config, seguranca
from app.main import app
from app.models import Sala, Usuario
from app.routers import auth

AGORA = datetime(2030, 8, 14, 9, 0, tzinfo=config.TIMEZONE)  # quarta-feira
DIA = "2030-08-15"
PEDIDOS = 6


@unittest.skipUnless(URL, "defina SALAFACIL_TEST_MYSQL_URL para rodar os testes de concorrência no MySQL")
class ConcorrenciaMySQLTests(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine(URL, pool_size=PEDIDOS + 2, pool_pre_ping=True)
        config.Base.metadata.drop_all(self.engine)
        config.Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine, autoflush=False)

        def db_teste():
            db = self.Session()
            try:
                yield db
            finally:
                db.close()

        app.dependency_overrides[seguranca.get_db] = db_teste
        auth.zerar_tentativas()
        senha = seguranca.hash_senha("123456")
        db = self.Session()
        db.add_all([Usuario(nome=f"Professor {i}", email=f"p{i}@escola.edu.br", senha=senha, perfil="professor")
                    for i in range(PEDIDOS)])
        db.add(Usuario(nome="Aluno", matricula="2026001", senha=senha, perfil="aluno"))
        db.add_all([Sala(codigo=f"S{i}", nome=f"Sala {i}", bloco="Bloco A", capacidade=30, permite_aluno=True)
                     for i in range(PEDIDOS)])
        db.commit()
        db.close()
        self.relogio = patch.object(config, "agora", return_value=AGORA)
        self.relogio.start()

    def tearDown(self):
        self.relogio.stop()
        app.dependency_overrides.clear()
        config.Base.metadata.drop_all(self.engine)
        self.engine.dispose()

    def token(self, login):
        r = TestClient(app).post("/auth/login", json={"login": login, "senha": "123456"})
        self.assertEqual(r.status_code, 200, r.text)
        return {"Authorization": f"Bearer {r.json()['access_token']}"}

    def disparar(self, pedidos):
        """Envia todos os pedidos ao mesmo tempo (uma barreira solta as threads juntas)."""
        barreira = threading.Barrier(len(pedidos))

        def enviar(pedido):
            cabecalho, corpo = pedido
            cliente = TestClient(app)
            barreira.wait()
            return cliente.post("/reservas", json=corpo, headers=cabecalho).status_code

        with ThreadPoolExecutor(len(pedidos)) as executor:
            return sorted(executor.map(enviar, pedidos))

    def corpo(self, sala_id, inicio="10:00", fim="12:00", pessoas=None):
        c = {"sala_id": sala_id, "data": DIA, "hora_inicio": inicio, "hora_fim": fim, "atividade": "Teste"}
        if pessoas:
            c["pessoas"] = pessoas
        return c

    def test_mesma_sala_mesmo_horario_so_um_consegue(self):
        tokens = [self.token(f"p{i}@escola.edu.br") for i in range(PEDIDOS)]
        resultado = self.disparar([(t, self.corpo(1)) for t in tokens])
        self.assertEqual(resultado, [201] + [409] * (PEDIDOS - 1))

    def test_mesma_pessoa_em_varias_salas_no_mesmo_horario_so_uma_vale(self):
        token = self.token("p0@escola.edu.br")
        resultado = self.disparar([(token, self.corpo(i + 1)) for i in range(PEDIDOS)])
        self.assertEqual(resultado, [201] + [409] * (PEDIDOS - 1))

    def test_limite_diario_do_aluno_com_pedidos_simultaneos(self):
        token = self.token("2026001")
        blocos = [("10:00", "12:00"), ("12:00", "14:00"), ("14:00", "16:00"), ("16:00", "18:00")]
        resultado = self.disparar([(token, self.corpo(i + 1, ini, fim, pessoas=2)) for i, (ini, fim) in enumerate(blocos)])
        self.assertEqual(resultado, [201] + [409] * (len(blocos) - 1))


if __name__ == "__main__":
    unittest.main()
