"""Configuração central: banco, fuso horário e regras de negócio ajustáveis."""

import os
import secrets
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "mysql+mysqlconnector://root:@localhost:3306/salafacil")
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

SESSION_SECRET = os.getenv("SESSION_SECRET", secrets.token_hex(32)).encode()
FRONTEND_ORIGINS = [o.strip() for o in os.getenv(
    "FRONTEND_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
).split(",") if o.strip()]

try:
    TIMEZONE = ZoneInfo("America/Sao_Paulo")
except ZoneInfoNotFoundError:
    TIMEZONE = timezone(timedelta(hours=-3), "America/Sao_Paulo")

# Regras do aluno (vieram do portal do estudante). Ajuste aqui se a instituição mudar.
BLOCOS_ALUNO = [("10:00", "12:00"), ("12:00", "14:00"), ("14:00", "16:00"), ("16:00", "18:00")]
LIMITE_DIARIO_ALUNO_MIN = 120  # 2 horas por dia

# Funcionamento para reservas, por dia da semana (0 = segunda ... 6 = domingo).
# Dias ausentes ficam fechados. Datas específicas (feriados) ficam na tabela datas_bloqueadas.
FUNCIONAMENTO = {
    0: ("07:00", "22:00"), 1: ("07:00", "22:00"), 2: ("07:00", "22:00"),
    3: ("07:00", "22:00"), 4: ("07:00", "22:00"),
    5: ("07:00", "12:00"),  # sábado só de manhã
}

# Agenda do professor: sem período informado, a API devolve a partir de N dias atrás (e todo o futuro).
HISTORICO_AGENDA_DIAS = 60

# Proteção contra força bruta no login: após N falhas na janela, novas tentativas ficam bloqueadas.
LOGIN_MAX_FALHAS_POR_LOGIN = 5
LOGIN_MAX_FALHAS_POR_IP = 20
LOGIN_JANELA_SEG = 15 * 60

# Janela usada no cálculo de ocupação semanal do painel do professor.
EXPEDIENTE = ("08:00", "18:00")


def agora() -> datetime:
    """Isolado numa função para os testes poderem "congelar" o relógio."""
    return datetime.now(TIMEZONE)
