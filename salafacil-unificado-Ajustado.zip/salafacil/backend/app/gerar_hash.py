"""Gera o hash de uma senha para inserir direto na tabela usuarios.
Uso (na pasta backend): python -m app.gerar_hash
"""

from getpass import getpass

from .seguranca import hash_senha

if __name__ == "__main__":
    senha = getpass("Senha: ")
    if len(senha) < 6:
        raise SystemExit("A senha precisa ter pelo menos 6 caracteres.")
    print(hash_senha(senha))
