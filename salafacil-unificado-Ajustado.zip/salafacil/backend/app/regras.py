"""Regras de negócio compartilhadas pelos routers (horários, conflitos, conversões)."""

from datetime import date, datetime, time
from typing import Iterable, Optional

from . import config
from .models import STATUS_CANCELADA, STATUS_CONCLUIDA, STATUS_CONFIRMADA, Reserva, Sala, Usuario
from .schemas import ReservaOut, SalaOut


def minutos(valor: time | str) -> int:
    if isinstance(valor, str):
        valor = datetime.strptime(valor, "%H:%M").time()
    return valor.hour * 60 + valor.minute


def hhmm(valor: time | int) -> str:
    if isinstance(valor, int):
        return f"{valor // 60:02d}:{valor % 60:02d}"
    return valor.strftime("%H:%M")


def minuto_atual(momento: datetime) -> int:
    return momento.hour * 60 + momento.minute


def sobrepoe(inicio_a: int, fim_a: int, inicio_b: int, fim_b: int) -> bool:
    return inicio_a < fim_b and fim_a > inicio_b


def ja_comecou(dia: date, inicio: time, momento: datetime) -> bool:
    return dia < momento.date() or (dia == momento.date() and minutos(inicio) <= minuto_atual(momento))


def status_reserva(reserva: Reserva, momento: datetime) -> str:
    if reserva.status == STATUS_CANCELADA:
        return STATUS_CANCELADA
    terminou = reserva.data < momento.date() or (
        reserva.data == momento.date() and minutos(reserva.hora_fim) <= minuto_atual(momento))
    return STATUS_CONCLUIDA if terminou else STATUS_CONFIRMADA


def reserva_out(reserva: Reserva, usuario: Usuario, momento: Optional[datetime] = None) -> ReservaOut:
    momento = momento or config.agora()
    return ReservaOut(
        id=reserva.id, codigo=reserva.codigo, sala_id=reserva.sala_id, sala_nome=reserva.sala.nome,
        usuario_id=reserva.usuario_id, responsavel=reserva.usuario.nome,
        perfil_responsavel=reserva.usuario.perfil, data=reserva.data,
        hora_inicio=hhmm(reserva.hora_inicio), hora_fim=hhmm(reserva.hora_fim),
        atividade=reserva.atividade, pessoas=reserva.pessoas,
        status=status_reserva(reserva, momento),
        pode_cancelar=(reserva.usuario_id == usuario.id and reserva.status == STATUS_CONFIRMADA
                       and not ja_comecou(reserva.data, reserva.hora_inicio, momento)),
        criado_em=reserva.criado_em.isoformat() if reserva.criado_em else None,
    )


DIAS = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo"]


def problema_funcionamento(db, dia: date, inicio: int, fim: int) -> Optional[str]:
    """Retorna a mensagem de erro se o período estiver fora do funcionamento (dia, horário ou data bloqueada)."""
    from .models import DataBloqueada  # import local evita ciclo
    w = dia.weekday()
    nos_dias = f"{'aos' if w >= 5 else 'às'} {DIAS[w]}s"  # "aos sábados", "às segundas"
    janela = config.FUNCIONAMENTO.get(w)
    if janela is None:
        return f"Não há reservas {nos_dias}. Funcionamento: segunda a sexta e sábado de manhã."
    if inicio < minutos(janela[0]) or fim > minutos(janela[1]):
        return f"{nos_dias.capitalize()}, as reservas devem ficar entre {janela[0]} e {janela[1]}."
    bloqueio = db.query(DataBloqueada).filter(DataBloqueada.data == dia).first()
    if bloqueio:
        return f"Não há reservas em {dia.strftime('%d/%m/%Y')}: {bloqueio.motivo}."
    return None


def situacao_agora(intervalos: list[tuple[int, int]], minuto: int) -> tuple[str, str]:
    """Retorna (status, detalhe) da sala no momento atual, a partir dos intervalos ocupados hoje."""
    intervalos = sorted(intervalos)
    atual = next(((i, f) for i, f in intervalos if i <= minuto < f), None)
    if atual:
        return "Ocupada", f"Ocupada até {hhmm(atual[1])}"
    proximo = next((i for i, _ in intervalos if i > minuto), None)
    if proximo is not None:
        return "Disponível", f"Livre até {hhmm(proximo)}"
    return "Disponível", "Livre o dia todo" if not intervalos else "Livre pelo restante do dia"


def sala_out(sala: Sala, reservas_hoje: Iterable[Reserva], momento: datetime,
             disponivel_periodo: Optional[bool] = None) -> SalaOut:
    intervalos = [(minutos(r.hora_inicio), minutos(r.hora_fim)) for r in reservas_hoje if r.sala_id == sala.id]
    status, detalhe = situacao_agora(intervalos, minuto_atual(momento))
    return SalaOut(
        id=sala.id, codigo=sala.codigo, nome=sala.nome, tipo=sala.tipo, bloco=sala.bloco, andar=sala.andar,
        campus=sala.campus, capacidade=sala.capacidade,
        recursos=[r.strip() for r in (sala.recursos or "").split("•") if r.strip()],
        descricao=sala.descricao, imagem=sala.imagem, permite_aluno=bool(sala.permite_aluno),
        status=status, detalhe_status=detalhe, disponivel_periodo=disponivel_periodo,
    )
