from datetime import date, time
from typing import Literal, Optional

from pydantic import BaseModel, Field

Perfil = Literal["aluno", "professor"]
StatusReserva = Literal["confirmada", "concluida", "cancelada"]


class UsuarioOut(BaseModel):
    id: int
    nome: str
    email: Optional[str] = None
    matricula: Optional[str] = None
    perfil: Perfil
    cargo: str


class LoginIn(BaseModel):
    login: str = Field(min_length=3, max_length=150, description="E-mail ou matrícula")
    senha: str = Field(min_length=1, max_length=255)


class CadastroIn(BaseModel):
    nome: str = Field(min_length=3, max_length=150)
    login: str = Field(min_length=3, max_length=150, description="Matrícula (só números) ou e-mail")
    senha: str = Field(min_length=6, max_length=255)


class SessaoOut(BaseModel):
    access_token: str
    usuario: UsuarioOut


class SalaOut(BaseModel):
    id: int
    codigo: str
    nome: str
    tipo: str
    bloco: str
    andar: int
    campus: str
    capacidade: int
    recursos: list[str]
    descricao: Optional[str] = None
    imagem: Optional[str] = None
    permite_aluno: bool
    status: Literal["Disponível", "Ocupada"]       # agora
    detalhe_status: str                             # ex.: "Livre até 14:00"
    disponivel_periodo: Optional[bool] = None       # só quando a busca informa data/início/fim


class Intervalo(BaseModel):
    inicio: str
    fim: str


class DisponibilidadeOut(BaseModel):
    sala_id: int
    data: date
    ocupados: list[Intervalo]


class Funcionamento(BaseModel):
    dia_semana: int  # 0 = segunda ... 6 = domingo
    inicio: str
    fim: str


class DataBloqueadaOut(BaseModel):
    id: int
    data: date
    motivo: str


class RegrasOut(BaseModel):
    blocos_aluno: list[Intervalo]
    limite_diario_aluno_min: int
    expediente: Intervalo
    funcionamento: list[Funcionamento]
    datas_bloqueadas: list[DataBloqueadaOut]


# ---------- Administração (somente professores) ----------

class SalaIn(BaseModel):
    codigo: str = Field(min_length=1, max_length=20)
    nome: str = Field(min_length=1, max_length=100)
    tipo: str = Field(min_length=1, max_length=50)
    bloco: str = Field(min_length=1, max_length=50)
    andar: int = Field(ge=-5, le=50)
    campus: str = Field(default="Campus Principal", min_length=1, max_length=100)
    capacidade: int = Field(ge=1, le=2000)
    recursos: list[str] = Field(default_factory=list)
    descricao: Optional[str] = Field(default=None, max_length=500)
    imagem: Optional[str] = Field(default=None, max_length=100, pattern=r"^[\w.-]*$")
    permite_aluno: bool = False


class SalaAdminOut(SalaOut):
    ativa: bool
    reservas_futuras: int


class AtivoIn(BaseModel):
    ativo: bool


class ProfessorIn(BaseModel):
    nome: str = Field(min_length=3, max_length=150)
    email: str = Field(min_length=5, max_length=150)
    cargo: Optional[str] = Field(default=None, max_length=100)
    senha: str = Field(min_length=6, max_length=255)


class ProfessorOut(BaseModel):
    id: int
    nome: str
    email: Optional[str] = None
    cargo: str
    ativo: bool
    reservas_futuras: int
    reservas_canceladas: int = 0  # preenchido só na resposta da desativação


class DataBloqueadaIn(BaseModel):
    data: date
    motivo: str = Field(min_length=2, max_length=150)


class ReservaIn(BaseModel):
    sala_id: int = Field(gt=0)
    data: date
    hora_inicio: time
    hora_fim: time
    atividade: str = Field(min_length=1, max_length=200)
    pessoas: Optional[int] = Field(default=None, ge=1)


class ReservaOut(BaseModel):
    id: int
    codigo: str
    sala_id: int
    sala_nome: str
    usuario_id: int
    responsavel: str
    perfil_responsavel: Perfil
    data: date
    hora_inicio: str
    hora_fim: str
    atividade: str
    pessoas: Optional[int] = None
    status: StatusReserva
    pode_cancelar: bool
    criado_em: Optional[str] = None
