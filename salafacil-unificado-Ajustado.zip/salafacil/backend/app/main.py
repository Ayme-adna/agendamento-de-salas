"""API SalaFácil (professores + alunos). Execute na pasta backend: uvicorn app.main:app --reload"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import config
from .routers import admin, auth, reservas, salas

app = FastAPI(title="SalaFácil API", version="3.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.FRONTEND_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)
app.include_router(auth.router)
app.include_router(salas.router)
app.include_router(reservas.router)
app.include_router(admin.router)
