"""Cria um banco SQLite (arquivo) com as tabelas e os dados de exemplo do schema.sql.

Use em computadores sem MySQL. Na pasta backend:
    .\\.venv\\Scripts\\python.exe -m app.criar_banco_sqlite
Depois inicie a API com:
    $env:DATABASE_URL = "sqlite:///salafacil.db"

ATENÇÃO: apaga e recria o arquivo salafacil.db.
"""

import ast
import os
import re
import sys
from datetime import date, time, timedelta
from pathlib import Path

PASTA_BACKEND = Path(__file__).resolve().parent.parent
ARQUIVO_DB = PASTA_BACKEND / "salafacil.db"
SCHEMA_SQL = PASTA_BACKEND.parent / "schema.sql"


def _converter(valor):
    """Datas e horas do schema.sql chegam como texto; o SQLAlchemy espera date/time."""
    if isinstance(valor, str):
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", valor):
            return date.fromisoformat(valor)
        if re.fullmatch(r"\d{2}:\d{2}", valor):
            return time.fromisoformat(valor)
    return valor


def main():
    if ARQUIVO_DB.exists():
        ARQUIVO_DB.unlink()
    # Precisa ser definido antes de importar a configuração (o engine é criado na importação).
    os.environ["DATABASE_URL"] = "sqlite:///" + ARQUIVO_DB.as_posix()

    from sqlalchemy import text

    from . import models  # noqa: F401  (registra as tabelas)
    from .config import Base, engine

    Base.metadata.create_all(engine)

    sql = SCHEMA_SQL.read_text(encoding="utf-8")
    sql = sql[sql.index("-- Usuários de exemplo"):]

    # Mesmo cálculo do schema.sql: próximo dia útil fora das datas bloqueadas.
    bloqueadas = {date.fromisoformat(d) for d in re.findall(r"\('(\d{4}-\d{2}-\d{2})', '[^']*', \d+\)", sql)}
    dia = date.today() + timedelta(days=1)
    while dia.weekday() > 4 or dia in bloqueadas:
        dia += timedelta(days=1)
    sql = sql.replace("@proximo_dia_util", f"'{dia.isoformat()}'")

    with engine.begin() as con:
        for m in re.finditer(r"INSERT INTO (\w+) \(([^)]*)\) VALUES(.*?);\s*\n", sql, re.S):
            tabela = Base.metadata.tables[m.group(1)]
            colunas = [c.strip() for c in m.group(2).split(",")]
            valores = re.sub(r"\bNULL\b", "None", m.group(3))
            valores = re.sub(r"\bTRUE\b", "True", re.sub(r"\bFALSE\b", "False", valores))
            linhas = ast.literal_eval("[" + valores + "]")
            con.execute(tabela.insert(), [{c: _converter(v) for c, v in zip(colunas, linha)} for linha in linhas])
        for t in ("usuarios", "salas", "reservas", "datas_bloqueadas"):
            print(f"{t}: {con.execute(text(f'SELECT COUNT(*) FROM {t}')).scalar()}")

    print(f"\nBanco criado em {ARQUIVO_DB}")
    print('Inicie a API com:  $env:DATABASE_URL = "sqlite:///salafacil.db"')


if __name__ == "__main__":
    sys.exit(main())
