import re
import threading
import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import or_
from sqlalchemy.orm import Session

from .. import config
from ..models import PERFIL_ALUNO, Usuario
from ..schemas import CadastroIn, LoginIn, SessaoOut, UsuarioOut
from ..seguranca import criar_token, get_db, hash_senha, usuario_atual, verificar_senha

router = APIRouter(prefix="/auth", tags=["Autenticação"])

RE_MATRICULA = re.compile(r"^\d{6,}$")
RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ---------- Limite de tentativas de login (em memória, por login e por IP) ----------
# Fica na memória do processo: reiniciar a API zera os contadores. Com vários processos/servidores,
# cada um conta separadamente; nesse cenário o ideal é mover para um armazenamento compartilhado (ex.: Redis).
_falhas: dict[str, deque] = defaultdict(deque)
_trava = threading.Lock()


def _recentes(chave: str, agora: float) -> deque:
    fila = _falhas[chave]
    while fila and fila[0] <= agora - config.LOGIN_JANELA_SEG:
        fila.popleft()
    return fila


def checar_bloqueio(login: str, ip: str):
    agora = time.monotonic()
    with _trava:
        limites = [(f"login:{login}", config.LOGIN_MAX_FALHAS_POR_LOGIN), (f"ip:{ip}", config.LOGIN_MAX_FALHAS_POR_IP)]
        espera = 0.0
        for chave, maximo in limites:
            fila = _recentes(chave, agora)
            if len(fila) >= maximo:
                espera = max(espera, fila[0] + config.LOGIN_JANELA_SEG - agora)
    if espera > 0:
        minutos = max(1, round(espera / 60))
        raise HTTPException(429, f"Muitas tentativas de login. Tente novamente em {minutos} minuto(s).",
                            headers={"Retry-After": str(int(espera) + 1)})


def registrar_falha(login: str, ip: str):
    agora = time.monotonic()
    with _trava:
        for chave in (f"login:{login}", f"ip:{ip}"):
            _recentes(chave, agora).append(agora)


def limpar_falhas(login: str):
    with _trava:
        _falhas.pop(f"login:{login}", None)


def zerar_tentativas():
    """Usado pelos testes."""
    with _trava:
        _falhas.clear()


def usuario_out(u: Usuario) -> UsuarioOut:
    cargo = u.cargo or ("Estudante" if u.perfil == PERFIL_ALUNO else "Professor(a)")
    return UsuarioOut(id=u.id, nome=u.nome, email=u.email, matricula=u.matricula, perfil=u.perfil, cargo=cargo)


@router.post("/login", response_model=SessaoOut)
def login(dados: LoginIn, request: Request, db: Session = Depends(get_db)):
    login = dados.login.strip().lower()
    ip = request.client.host if request.client else "desconhecido"
    checar_bloqueio(login, ip)
    usuario = db.query(Usuario).filter(or_(Usuario.email == login, Usuario.matricula == login)).first()
    if usuario is None or not usuario.ativo or not verificar_senha(dados.senha, usuario.senha):
        registrar_falha(login, ip)
        raise HTTPException(401, "E-mail/matrícula ou senha incorretos.")
    limpar_falhas(login)
    return SessaoOut(access_token=criar_token(usuario.id), usuario=usuario_out(usuario))


@router.post("/cadastro", response_model=SessaoOut, status_code=201)
def cadastro(dados: CadastroIn, db: Session = Depends(get_db)):
    """Autocadastro: sempre cria um ALUNO. Professores são cadastrados pela instituição."""
    nome = dados.nome.strip()
    login = dados.login.strip().lower()
    if len(nome) < 3:
        raise HTTPException(422, "Informe seu nome completo.")
    eh_matricula = bool(RE_MATRICULA.match(login))
    if not eh_matricula and not RE_EMAIL.match(login):
        raise HTTPException(422, "Use sua matrícula (só números, mínimo 6) ou seu e-mail institucional.")
    existe = db.query(Usuario).filter(or_(Usuario.email == login, Usuario.matricula == login)).first()
    if existe:
        raise HTTPException(409, "Já existe cadastro com essa matrícula/e-mail.")
    usuario = Usuario(nome=nome, senha=hash_senha(dados.senha), perfil=PERFIL_ALUNO, cargo="Estudante",
                      matricula=login if eh_matricula else None, email=None if eh_matricula else login)
    db.add(usuario)
    db.commit()
    db.refresh(usuario)
    return SessaoOut(access_token=criar_token(usuario.id), usuario=usuario_out(usuario))


@router.get("/me", response_model=UsuarioOut)
def perfil(usuario: Usuario = Depends(usuario_atual)):
    return usuario_out(usuario)
