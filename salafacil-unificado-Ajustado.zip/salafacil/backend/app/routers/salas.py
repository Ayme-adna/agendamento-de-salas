from datetime import date, time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from .. import config
from ..models import STATUS_CONFIRMADA, DataBloqueada, Reserva, Sala, Usuario
from ..regras import hhmm, ja_comecou, minutos, problema_funcionamento, sala_out, sobrepoe
from ..schemas import DataBloqueadaOut, DisponibilidadeOut, Funcionamento, Intervalo, RegrasOut, SalaOut
from ..seguranca import eh_professor, get_db, usuario_atual

router = APIRouter(tags=["Salas"])


def salas_visiveis(db: Session, usuario: Usuario):
    consulta = db.query(Sala).filter(Sala.ativa.is_(True))
    if not eh_professor(usuario):
        consulta = consulta.filter(Sala.permite_aluno.is_(True))
    return consulta


def reservas_confirmadas(db: Session, dia: date, sala_id: Optional[int] = None):
    consulta = db.query(Reserva).filter(Reserva.data == dia, Reserva.status == STATUS_CONFIRMADA)
    if sala_id is not None:
        consulta = consulta.filter(Reserva.sala_id == sala_id)
    return consulta.all()


@router.get("/regras", response_model=RegrasOut)
def regras(db: Session = Depends(get_db)):
    """Regras que o frontend usa para montar as telas (fonte única de verdade)."""
    bloqueios = db.query(DataBloqueada).filter(DataBloqueada.data >= config.agora().date()) \
        .order_by(DataBloqueada.data).all()
    return RegrasOut(
        blocos_aluno=[Intervalo(inicio=i, fim=f) for i, f in config.BLOCOS_ALUNO],
        limite_diario_aluno_min=config.LIMITE_DIARIO_ALUNO_MIN,
        expediente=Intervalo(inicio=config.EXPEDIENTE[0], fim=config.EXPEDIENTE[1]),
        funcionamento=[Funcionamento(dia_semana=d, inicio=i, fim=f) for d, (i, f) in sorted(config.FUNCIONAMENTO.items())],
        datas_bloqueadas=[DataBloqueadaOut(id=b.id, data=b.data, motivo=b.motivo) for b in bloqueios],
    )


@router.get("/salas", response_model=list[SalaOut])
def listar_salas(
    data: Optional[date] = Query(None, description="Data para checar disponibilidade"),
    inicio: Optional[time] = Query(None), fim: Optional[time] = Query(None),
    pessoas: Optional[int] = Query(None, ge=1), busca: str = Query("", max_length=100),
    db: Session = Depends(get_db), usuario: Usuario = Depends(usuario_atual),
):
    momento = config.agora()
    consulta = salas_visiveis(db, usuario)
    if pessoas:
        consulta = consulta.filter(Sala.capacidade >= pessoas)
    salas = consulta.order_by(Sala.bloco, Sala.nome).all()
    termo = busca.strip().lower()
    if termo:
        salas = [s for s in salas if termo in f"{s.codigo} {s.nome} {s.tipo} {s.bloco} {s.recursos or ''}".lower()]

    hoje = reservas_confirmadas(db, momento.date())
    periodo = None
    if data and inicio and fim:
        if minutos(inicio) >= minutos(fim):
            raise HTTPException(422, "O término deve ser depois do início.")
        periodo = reservas_confirmadas(db, data)

    passou = periodo is not None and (ja_comecou(data, inicio, momento) or bool(
        problema_funcionamento(db, data, minutos(inicio), minutos(fim))))
    resultado = []
    for sala in salas:
        livre = None
        if periodo is not None:
            livre = not passou and not any(r.sala_id == sala.id and sobrepoe(minutos(inicio), minutos(fim),
                                                              minutos(r.hora_inicio), minutos(r.hora_fim))
                            for r in periodo)
        resultado.append(sala_out(sala, hoje, momento, livre))
    return resultado


@router.get("/salas/{sala_id}", response_model=SalaOut)
def detalhar_sala(sala_id: int, db: Session = Depends(get_db), usuario: Usuario = Depends(usuario_atual)):
    sala = salas_visiveis(db, usuario).filter(Sala.id == sala_id).first()
    if sala is None:
        raise HTTPException(404, "Sala não encontrada.")
    momento = config.agora()
    return sala_out(sala, reservas_confirmadas(db, momento.date(), sala.id), momento)


@router.get("/salas/{sala_id}/disponibilidade", response_model=DisponibilidadeOut)
def disponibilidade(sala_id: int, data: date, db: Session = Depends(get_db),
                    usuario: Usuario = Depends(usuario_atual)):
    """Horários ocupados da sala no dia — sem expor quem reservou."""
    if salas_visiveis(db, usuario).filter(Sala.id == sala_id).first() is None:
        raise HTTPException(404, "Sala não encontrada.")
    ocupados = sorted(reservas_confirmadas(db, data, sala_id), key=lambda r: r.hora_inicio)
    return DisponibilidadeOut(sala_id=sala_id, data=data, ocupados=[
        Intervalo(inicio=hhmm(r.hora_inicio), fim=hhmm(r.hora_fim)) for r in ocupados])
