export type Perfil = "aluno" | "professor";

export interface Usuario {
  id: number;
  nome: string;
  email: string | null;
  matricula: string | null;
  perfil: Perfil;
  cargo: string;
}

export interface Sessao {
  access_token: string;
  usuario: Usuario;
}

export interface Sala {
  id: number;
  codigo: string;
  nome: string;
  tipo: string;
  bloco: string;
  andar: number;
  campus: string;
  capacidade: number;
  recursos: string[];
  descricao: string | null;
  imagem: string | null;
  permite_aluno: boolean;
  status: "Disponível" | "Ocupada";
  detalhe_status: string;
  disponivel_periodo: boolean | null;
}

export interface Intervalo {
  inicio: string;
  fim: string;
}

export interface DataBloqueada {
  id: number;
  data: string;
  motivo: string;
}

export interface Regras {
  blocos_aluno: Intervalo[];
  limite_diario_aluno_min: number;
  expediente: Intervalo;
  /** dia_semana: 0 = segunda ... 6 = domingo. Dias ausentes = fechado. */
  funcionamento: (Intervalo & { dia_semana: number })[];
  datas_bloqueadas: DataBloqueada[];
}

// ---------- Administração ----------
export interface SalaIn {
  codigo: string;
  nome: string;
  tipo: string;
  bloco: string;
  andar: number;
  campus: string;
  capacidade: number;
  recursos: string[];
  descricao: string | null;
  imagem: string | null;
  permite_aluno: boolean;
}
export interface SalaAdmin extends Sala {
  ativa: boolean;
  reservas_futuras: number;
}
export interface ProfessorIn {
  nome: string;
  email: string;
  cargo: string | null;
  senha: string;
}
export interface Professor {
  id: number;
  nome: string;
  email: string | null;
  cargo: string;
  ativo: boolean;
  reservas_futuras: number;
  reservas_canceladas?: number;
}

export interface ReservaCreate {
  sala_id: number;
  data: string;
  hora_inicio: string;
  hora_fim: string;
  atividade: string;
  pessoas?: number;
}

export type StatusReserva = "confirmada" | "concluida" | "cancelada";

export interface Reserva {
  id: number;
  codigo: string;
  sala_id: number;
  sala_nome: string;
  usuario_id: number;
  responsavel: string;
  perfil_responsavel: Perfil;
  data: string;
  hora_inicio: string;
  hora_fim: string;
  atividade: string;
  pessoas: number | null;
  status: StatusReserva;
  pode_cancelar: boolean;
  criado_em: string | null;
}

export interface FiltroSalas {
  data?: string;
  inicio?: string;
  fim?: string;
  pessoas?: number;
  busca?: string;
}
