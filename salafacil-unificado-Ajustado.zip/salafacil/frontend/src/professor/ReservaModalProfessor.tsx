import { useState } from "react";
import type { FormEvent } from "react";
import { criarReserva, mensagemErro } from "../api";
import { CabecalhoModal, Erro, Modal } from "../componentes/Comuns";
import { Icon } from "../componentes/Icon";
import type { Regras, Reserva, Sala } from "../types";
import { hoje, problemaPeriodo, proximoDiaAberto, sobrepoe } from "../util";

interface Props {
  regras: Regras;
  salas: Sala[];
  reservas: Reserva[];
  usuarioId: number;
  salaInicial: number | null;
  dataInicial: string;
  onFechar: () => void;
  onSalvar: (reserva: Reserva) => void;
}

/** Agendamento do professor: intervalo livre, qualquer sala. */
export function ReservaModalProfessor({ regras, salas, reservas, usuarioId, salaInicial, dataInicial, onFechar, onSalvar }: Props) {
  const [atividade, setAtividade] = useState("");
  const [data, setData] = useState(proximoDiaAberto(regras, dataInicial < hoje() ? hoje() : dataInicial));
  const [inicio, setInicio] = useState("16:00");
  const [fim, setFim] = useState("17:30");
  const [pessoas, setPessoas] = useState("");
  const [salaId, setSalaId] = useState(salaInicial ? String(salaInicial) : "");
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [confirmado, setConfirmado] = useState(false);
  const conflito = (id: number) => reservas.some(r => r.sala_id === id && r.data === data && r.status !== "cancelada" && sobrepoe({ inicio, fim }, { inicio: r.hora_inicio, fim: r.hora_fim }));
  const sala = salas.find(s => String(s.id) === salaId);
  const foraDoFuncionamento = inicio < fim ? problemaPeriodo(regras, data, inicio, fim) : null;
  // Uma sala por pessoa no mesmo horário: avisa antes de enviar.
  const minhaNoHorario = reservas.find(r => r.status === "confirmada" && r.data === data && r.usuario_id === usuarioId && sobrepoe({ inicio, fim }, { inicio: r.hora_inicio, fim: r.hora_fim }));

  async function salvar(event: FormEvent) {
    event.preventDefault(); setErro("");
    if (!atividade.trim()) { setErro("Informe o nome da atividade."); return; }
    if (inicio >= fim) { setErro("O término deve ser depois do início."); return; }
    if (foraDoFuncionamento) { setErro(foraDoFuncionamento); return; }
    if (minhaNoHorario) { setErro(`Você já tem uma reserva nesse horário (${minhaNoHorario.sala_nome}, ${minhaNoHorario.hora_inicio}–${minhaNoHorario.hora_fim}).`); return; }
    if (conflito(Number(salaId))) { setErro("Esta sala já está reservada nesse horário. Escolha outro período."); return; }
    if (sala && pessoas && Number(pessoas) > sala.capacidade) { setErro(`A sala comporta até ${sala.capacidade} pessoas.`); return; }
    setSalvando(true);
    try {
      const reserva = await criarReserva({ atividade: atividade.trim(), data, hora_inicio: inicio, hora_fim: fim, sala_id: Number(salaId), ...(pessoas ? { pessoas: Number(pessoas) } : {}) });
      onSalvar(reserva); setConfirmado(true);
    } catch (e) { setErro(mensagemErro(e)); }
    finally { setSalvando(false); }
  }

  if (confirmado) return <Modal titulo="Agendamento confirmado" onFechar={onFechar} className="modal-sucesso"><span className="sucesso-icone"><Icon nome="check" size={27} /></span><h2>Agendamento confirmado</h2><p>A sala foi reservada e já está disponível na agenda semanal.</p><button autoFocus className="botao primario" onClick={onFechar}>Voltar para a agenda</button></Modal>;

  return <Modal titulo="Novo agendamento" onFechar={onFechar} bloqueado={salvando}><form onSubmit={salvar}>
    <CabecalhoModal titulo="Novo agendamento" onFechar={onFechar} bloqueado={salvando} />
    <p>Preencha os dados para reservar um espaço.</p>
    <fieldset disabled={salvando}>
      <label htmlFor="atividade">Atividade</label><input id="atividade" autoFocus value={atividade} onChange={e => setAtividade(e.target.value)} maxLength={200} placeholder="Ex.: Aula de Biologia" required />
      <div className="form-linha"><div><label htmlFor="data">Data</label><input id="data" type="date" min={hoje()} value={data} onChange={e => setData(e.target.value)} required /></div><div><label htmlFor="inicio">Início</label><input id="inicio" type="time" value={inicio} onChange={e => setInicio(e.target.value)} required /></div><div><label htmlFor="fim">Término</label><input id="fim" type="time" value={fim} onChange={e => setFim(e.target.value)} required /></div></div>
      {(foraDoFuncionamento || minhaNoHorario) && <p className="aviso alerta">{foraDoFuncionamento ?? `Você já tem uma reserva nesse horário: ${minhaNoHorario!.atividade} (${minhaNoHorario!.sala_nome}).`}</p>}
      <div className="form-linha duas"><div><label htmlFor="sala">Sala</label><select className={salaId ? "selecionado" : ""} id="sala" value={salaId} onChange={e => setSalaId(e.target.value)} required><option value="" disabled>Selecione um espaço</option>{salas.map(s => <option value={s.id} key={s.id} disabled={conflito(s.id)}>{s.nome} · {s.bloco}{conflito(s.id) ? " (reservada neste horário)" : ""}</option>)}</select></div>
        <div><label htmlFor="pessoas">Pessoas</label><input id="pessoas" type="number" min={1} max={sala?.capacidade} value={pessoas} onChange={e => setPessoas(e.target.value)} placeholder={sala ? `até ${sala.capacidade}` : "opcional"} /></div></div>
      <Erro texto={erro} /><div className="modal-acoes"><button className="botao secundario" type="button" onClick={onFechar}>Cancelar</button><button className="botao primario" type="submit" disabled={!salas.length || salvando}>{salvando ? "Confirmando…" : "Confirmar agendamento"}</button></div>
    </fieldset>
  </form></Modal>;
}
