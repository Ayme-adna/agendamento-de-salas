import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { EVENTO_ATUALIZAR, admin, mensagemErro } from "../api";
import { CabecalhoModal, Erro, FotoSala, Modal, Vazio } from "../componentes/Comuns";
import { Icon } from "../componentes/Icon";
import type { DataBloqueada, Professor, SalaAdmin, SalaIn, Usuario } from "../types";
import { andar, formatar, hoje } from "../util";

type Aba = "salas" | "professores" | "datas";
const avisarMudanca = () => window.dispatchEvent(new Event(EVENTO_ATUALIZAR));

/** Área administrativa do professor: salas, professores e datas bloqueadas. */
export function Administracao({ usuario }: { usuario: Usuario }) {
  const [aba, setAba] = useState<Aba>("salas");
  return <>
    <div className="filtros" role="tablist" aria-label="Seções da administração">
      {([["salas", "Salas"], ["professores", "Professores"], ["datas", "Datas bloqueadas"]] as const).map(([id, nome]) =>
        <button key={id} role="tab" aria-selected={aba === id} className={`botao ${aba === id ? "filtro-ativo" : "secundario"}`} onClick={() => setAba(id)}>{nome}</button>)}
    </div>
    {aba === "salas" && <AdminSalas />}
    {aba === "professores" && <AdminProfessores usuario={usuario} />}
    {aba === "datas" && <AdminDatas />}
  </>;
}

/** Carrega uma lista da API com estados de carregando/erro. */
function useLista<T>(carregar: () => Promise<T[]>) {
  const [lista, setLista] = useState<T[] | null>(null);
  const [erro, setErro] = useState("");
  const recarregar = () => carregar().then(l => { setLista(l); setErro(""); }).catch(e => setErro(mensagemErro(e)));
  useEffect(() => { void recarregar(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return { lista, setLista, erro, setErro, recarregar };
}

// ======================= SALAS =======================

function AdminSalas() {
  const { lista, erro, setErro, recarregar } = useLista(admin.salas);
  const [editando, setEditando] = useState<SalaAdmin | "nova" | null>(null);
  const [ocupado, setOcupado] = useState<number | null>(null);

  async function alternar(s: SalaAdmin) {
    setErro(""); setOcupado(s.id);
    try { await admin.ativarSala(s.id, !s.ativa); await recarregar(); avisarMudanca(); }
    catch (e) { setErro(mensagemErro(e)); }
    finally { setOcupado(null); }
  }

  return <>
    <div className="secao-cabecalho"><div><h2>Salas cadastradas</h2><small>{lista ? `${lista.filter(s => s.ativa).length} ativas · ${lista.filter(s => !s.ativa).length} desativadas` : "Carregando…"}</small></div><button className="botao primario" onClick={() => setEditando("nova")}><Icon nome="mais" size={15} />Nova sala</button></div>
    <Erro texto={erro} />
    <section className="painel lista-admin">
      {lista?.map(s => <article key={s.id} className={`admin-linha ${s.ativa ? "" : "inativa"}`}>
        <FotoSala sala={s} className="mini" />
        <div className="admin-info"><h3>{s.nome} <small>· {s.codigo}</small></h3><p>{s.tipo} · {s.bloco} · {andar(s.andar)} · {s.capacidade} lugares</p></div>
        <div className="admin-tags">{s.permite_aluno ? <span className="tag-aluno">Aberta a alunos</span> : <span className="chip">Só professores</span>}{s.reservas_futuras > 0 && <span className="chip">{s.reservas_futuras} reserva(s) futura(s)</span>}</div>
        <span className={`badge ${s.ativa ? "" : "concluido"}`}>{s.ativa ? "Ativa" : "Desativada"}</span>
        <div className="admin-acoes"><button className="link" onClick={() => setEditando(s)}><Icon nome="editar" size={13} />Editar</button><button className={`link ${s.ativa ? "perigo" : ""}`} disabled={ocupado === s.id} onClick={() => alternar(s)}>{s.ativa ? "Desativar" : "Reativar"}</button></div>
      </article>)}
      {lista && !lista.length && <Vazio texto="Nenhuma sala cadastrada." />}
    </section>
    {editando && <SalaForm sala={editando === "nova" ? null : editando} onFechar={() => setEditando(null)} onSalvo={() => { setEditando(null); void recarregar(); avisarMudanca(); }} />}
  </>;
}

const TIPOS = ["Sala de aula", "Laboratório", "Auditório", "Estudo em grupo", "Outro"];

function SalaForm({ sala, onFechar, onSalvo }: { sala: SalaAdmin | null; onFechar: () => void; onSalvo: () => void }) {
  const [f, setF] = useState<SalaIn>(() => sala
    ? { codigo: sala.codigo, nome: sala.nome, tipo: sala.tipo, bloco: sala.bloco, andar: sala.andar, campus: sala.campus, capacidade: sala.capacidade, recursos: sala.recursos, descricao: sala.descricao, imagem: sala.imagem, permite_aluno: sala.permite_aluno }
    : { codigo: "", nome: "", tipo: "Sala de aula", bloco: "", andar: 0, campus: "Campus Principal", capacidade: 30, recursos: [], descricao: null, imagem: null, permite_aluno: false });
  const [recursos, setRecursos] = useState(f.recursos.join(", "));
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);
  const campo = <K extends keyof SalaIn>(k: K, v: SalaIn[K]) => setF(atual => ({ ...atual, [k]: v }));

  async function salvar(e: FormEvent) {
    e.preventDefault(); setErro(""); setSalvando(true);
    const dados = { ...f, recursos: recursos.split(/[,•]/).map(r => r.trim()).filter(Boolean) };
    try { await (sala ? admin.editarSala(sala.id, dados) : admin.criarSala(dados)); onSalvo(); }
    catch (x) { setErro(mensagemErro(x)); }
    finally { setSalvando(false); }
  }

  const titulo = sala ? `Editar ${sala.nome}` : "Nova sala";
  return <Modal titulo={titulo} onFechar={onFechar} bloqueado={salvando} className="modal-largo"><form onSubmit={salvar}>
    <CabecalhoModal titulo={titulo} onFechar={onFechar} bloqueado={salvando} />
    <fieldset disabled={salvando}>
      <div className="form-grade">
        <div><label htmlFor="s-codigo">Código</label><input id="s-codigo" value={f.codigo} maxLength={20} onChange={e => campo("codigo", e.target.value)} placeholder="Ex.: D101" required /></div>
        <div className="larga"><label htmlFor="s-nome">Nome</label><input id="s-nome" value={f.nome} maxLength={100} onChange={e => campo("nome", e.target.value)} placeholder="Ex.: Sala D101" required /></div>
        <div><label htmlFor="s-tipo">Tipo</label><select id="s-tipo" value={TIPOS.includes(f.tipo) ? f.tipo : "Outro"} onChange={e => campo("tipo", e.target.value)}>{TIPOS.map(t => <option key={t}>{t}</option>)}</select></div>
        <div><label htmlFor="s-bloco">Bloco</label><input id="s-bloco" value={f.bloco} maxLength={50} onChange={e => campo("bloco", e.target.value)} placeholder="Ex.: Bloco D" required /></div>
        <div><label htmlFor="s-andar">Andar (0 = térreo)</label><input id="s-andar" type="number" min={-5} max={50} value={f.andar} onChange={e => campo("andar", Number(e.target.value))} required /></div>
        <div><label htmlFor="s-cap">Capacidade</label><input id="s-cap" type="number" min={1} max={2000} value={f.capacidade} onChange={e => campo("capacidade", Number(e.target.value))} required /></div>
        <div className="larga"><label htmlFor="s-campus">Campus</label><input id="s-campus" value={f.campus} maxLength={100} onChange={e => campo("campus", e.target.value)} required /></div>
        <div className="inteira"><label htmlFor="s-rec">Recursos (separados por vírgula)</label><input id="s-rec" value={recursos} onChange={e => setRecursos(e.target.value)} placeholder="Wi-Fi, Projetor, Quadro branco" /></div>
        <div className="inteira"><label htmlFor="s-desc">Descrição</label><input id="s-desc" value={f.descricao ?? ""} maxLength={500} onChange={e => campo("descricao", e.target.value)} placeholder="Opcional" /></div>
        <div className="inteira"><label htmlFor="s-img">Arquivo da foto em frontend/public/img</label><input id="s-img" value={f.imagem ?? ""} maxLength={100} pattern="[\w.\-]*" onChange={e => campo("imagem", e.target.value)} placeholder="Ex.: D101.jpg (opcional)" /></div>
      </div>
      <label className="checkbox aceite"><input type="checkbox" checked={f.permite_aluno} onChange={e => campo("permite_aluno", e.target.checked)} /><span>Aberta a alunos — aparece na busca do portal do estudante (reservas em blocos de 2h).</span></label>
      <Erro texto={erro} />
      <div className="modal-acoes"><button type="button" className="botao secundario" onClick={onFechar}>Cancelar</button><button className="botao primario">{salvando ? "Salvando…" : sala ? "Salvar alterações" : "Cadastrar sala"}</button></div>
    </fieldset>
  </form></Modal>;
}

// ======================= PROFESSORES =======================

function AdminProfessores({ usuario }: { usuario: Usuario }) {
  const { lista, erro, setErro, recarregar } = useLista(admin.professores);
  const [novo, setNovo] = useState(false);
  const [ocupado, setOcupado] = useState<number | null>(null);
  const [confirmando, setConfirmando] = useState<Professor | null>(null);
  const [aviso, setAviso] = useState("");

  async function alternar(p: Professor) {
    setErro(""); setAviso(""); setOcupado(p.id);
    try {
      const r = await admin.ativarProfessor(p.id, !p.ativo);
      await recarregar(); avisarMudanca();
      setAviso(p.ativo
        ? `Acesso de ${p.nome} desativado.${r.reservas_canceladas ? ` ${r.reservas_canceladas} reserva(s) futura(s) cancelada(s) e salas liberadas.` : ""}`
        : `Acesso de ${p.nome} reativado.`);
    }
    catch (e) { setErro(mensagemErro(e)); }
    finally { setOcupado(null); setConfirmando(null); }
  }

  return <>
    <div className="secao-cabecalho"><div><h2>Professores</h2><small>Professores entram com o e-mail e a senha cadastrados aqui. Alunos se cadastram sozinhos no portal.</small></div><button className="botao primario" onClick={() => setNovo(true)}><Icon nome="mais" size={15} />Novo professor</button></div>
    <Erro texto={erro} />
    {aviso && <p className="aviso" role="status">{aviso}</p>}
    <section className="painel lista-admin">
      {lista?.map(p => <article key={p.id} className={`admin-linha sem-foto ${p.ativo ? "" : "inativa"}`}>
        <span className="avatar">{p.nome.split(" ").filter(Boolean).slice(0, 2).map(x => x[0]).join("").toUpperCase()}</span>
        <div className="admin-info"><h3>{p.nome}{p.id === usuario.id && <small> · você</small>}</h3><p>{p.email} · {p.cargo}</p></div>
        <div className="admin-tags">{p.reservas_futuras > 0 && <span className="chip">{p.reservas_futuras} reserva(s) futura(s)</span>}</div>
        <span className={`badge ${p.ativo ? "" : "concluido"}`}>{p.ativo ? "Ativo" : "Desativado"}</span>
        <div className="admin-acoes">{p.id !== usuario.id && <button className={`link ${p.ativo ? "perigo" : ""}`} disabled={ocupado === p.id} onClick={() => p.ativo ? setConfirmando(p) : alternar(p)}>{p.ativo ? "Desativar acesso" : "Reativar acesso"}</button>}</div>
      </article>)}
    </section>
    {novo && <ProfessorForm onFechar={() => setNovo(false)} onSalvo={() => { setNovo(false); void recarregar(); }} />}
    {confirmando && <Modal titulo="Desativar acesso" onFechar={() => setConfirmando(null)} bloqueado={ocupado !== null}>
      <CabecalhoModal titulo="Desativar acesso" onFechar={() => setConfirmando(null)} bloqueado={ocupado !== null} />
      <p><b>{confirmando.nome}</b> não conseguirá mais entrar no sistema.{confirmando.reservas_futuras > 0
        ? <> As <b>{confirmando.reservas_futuras} reserva(s) futura(s)</b> dele(a) serão canceladas e as salas ficarão livres. Uma aula que já estiver em andamento é mantida.</>
        : " Ele(a) não tem reservas futuras."}</p>
      <p>Você pode reativar o acesso depois, mas as reservas canceladas não voltam.</p>
      <div className="modal-acoes"><button className="botao secundario" onClick={() => setConfirmando(null)} disabled={ocupado !== null}>Voltar</button><button autoFocus className="botao perigo" onClick={() => alternar(confirmando)} disabled={ocupado !== null}>{ocupado !== null ? "Desativando…" : "Desativar acesso"}</button></div>
    </Modal>}
  </>;
}

function ProfessorForm({ onFechar, onSalvo }: { onFechar: () => void; onSalvo: () => void }) {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [cargo, setCargo] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);
  async function salvar(e: FormEvent) {
    e.preventDefault(); setErro(""); setSalvando(true);
    try { await admin.criarProfessor({ nome: nome.trim(), email: email.trim(), cargo: cargo.trim() || null, senha }); onSalvo(); }
    catch (x) { setErro(mensagemErro(x)); }
    finally { setSalvando(false); }
  }
  return <Modal titulo="Novo professor" onFechar={onFechar} bloqueado={salvando}><form onSubmit={salvar}>
    <CabecalhoModal titulo="Novo professor" onFechar={onFechar} bloqueado={salvando} />
    <p>Informe uma senha inicial e repasse ao professor. Ele entra com o e-mail institucional.</p>
    <fieldset disabled={salvando}>
      <label htmlFor="p-nome">Nome completo</label><input id="p-nome" autoFocus value={nome} minLength={3} maxLength={150} onChange={e => setNome(e.target.value)} required />
      <label htmlFor="p-email">E-mail institucional</label><input id="p-email" type="email" value={email} maxLength={150} onChange={e => setEmail(e.target.value)} placeholder="nome@escola.edu.br" required />
      <label htmlFor="p-cargo">Cargo / disciplina</label><input id="p-cargo" value={cargo} maxLength={100} onChange={e => setCargo(e.target.value)} placeholder="Ex.: Professora de Química (opcional)" />
      <label htmlFor="p-senha">Senha inicial (mínimo 6 caracteres)</label><input id="p-senha" type="text" autoComplete="off" value={senha} minLength={6} maxLength={255} onChange={e => setSenha(e.target.value)} required />
      <Erro texto={erro} />
      <div className="modal-acoes"><button type="button" className="botao secundario" onClick={onFechar}>Cancelar</button><button className="botao primario">{salvando ? "Cadastrando…" : "Cadastrar professor"}</button></div>
    </fieldset>
  </form></Modal>;
}

// ======================= DATAS BLOQUEADAS =======================

function AdminDatas() {
  const { lista, erro, setErro, recarregar } = useLista<DataBloqueada>(admin.datas);
  const [data, setData] = useState("");
  const [motivo, setMotivo] = useState("");
  const [salvando, setSalvando] = useState(false);

  async function bloquear(e: FormEvent) {
    e.preventDefault(); setErro(""); setSalvando(true);
    try { await admin.bloquearData(data, motivo.trim()); setData(""); setMotivo(""); await recarregar(); avisarMudanca(); }
    catch (x) { setErro(mensagemErro(x)); }
    finally { setSalvando(false); }
  }
  async function remover(d: DataBloqueada) {
    setErro("");
    try { await admin.desbloquearData(d.id); await recarregar(); avisarMudanca(); }
    catch (x) { setErro(mensagemErro(x)); }
  }
  const futuras = (lista ?? []).filter(d => d.data >= hoje());
  const passadas = (lista ?? []).filter(d => d.data < hoje());

  return <>
    <div className="secao-cabecalho"><div><h2>Datas sem reservas</h2><small>Feriados, recessos e eventos. Nessas datas ninguém consegue reservar. Domingos já são fechados automaticamente.</small></div></div>
    <form className="painel filtros-busca datas" onSubmit={bloquear}>
      <div><label htmlFor="b-data">Data</label><input id="b-data" type="date" min={hoje()} value={data} onChange={e => setData(e.target.value)} required /></div>
      <div><label htmlFor="b-motivo">Motivo</label><input id="b-motivo" value={motivo} minLength={2} maxLength={150} onChange={e => setMotivo(e.target.value)} placeholder="Ex.: Feriado municipal" required /></div>
      <button className="botao primario" disabled={salvando}><Icon nome="bloqueio" size={15} />{salvando ? "Bloqueando…" : "Bloquear data"}</button>
    </form>
    <Erro texto={erro} />
    <section className="painel lista-admin">
      {futuras.map(d => <article key={d.id} className="admin-linha sem-foto"><span className="porta-icone ocupada"><Icon nome="bloqueio" size={17} /></span><div className="admin-info"><h3 className="primeira-maiuscula">{formatar(d.data, { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}</h3><p>{d.motivo}</p></div><div /><span className="badge ocupada">Bloqueada</span><div className="admin-acoes"><button className="link" onClick={() => remover(d)}>Liberar data</button></div></article>)}
      {lista && !futuras.length && <Vazio texto="Nenhuma data futura bloqueada." />}
      {passadas.length > 0 && <footer>{passadas.length} data(s) passada(s) mantida(s) no histórico</footer>}
    </section>
  </>;
}
