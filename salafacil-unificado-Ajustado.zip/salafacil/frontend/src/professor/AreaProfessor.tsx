import { useState } from "react";
import { CancelarModal } from "../componentes/CancelarModal";
import { FotoSala, Vazio } from "../componentes/Comuns";
import { Icon } from "../componentes/Icon";
import { CabecalhoPagina, Layout } from "../componentes/Layout";
import type { Reserva, Usuario } from "../types";
import { useDados } from "../useDados";
import { dataCurta, dataLocal, diaSemana, duracao, formatar, hoje, janela, minutos, normalizar, problemaDia, rotuloStatus, semana, somarDias } from "../util";
import { Administracao } from "./Administracao";
import { ReservaModalProfessor } from "./ReservaModalProfessor";

type Pagina = "inicio" | "agendamentos" | "salas" | "admin";
type Filtro = "Todos" | "Próximos" | "Concluídos" | "Meus";
const HISTORICO_DIAS = 60; // mesmo valor de HISTORICO_AGENDA_DIAS no backend

export function AreaProfessor({ usuario, onSair }: { usuario: Usuario; onSair: () => void }) {
  const [pagina, setPagina] = useState<Pagina>("inicio");
  const [busca, setBusca] = useState("");
  const [filtro, setFiltro] = useState<Filtro>("Todos");
  // Domingo não tem reservas: abre na segunda-feira seguinte.
  const [dataSelecionada, setDataSelecionada] = useState(() => diaSemana(hoje()) === 6 ? somarDias(hoje(), 1) : hoje());
  // A API devolve os últimos 60 dias; ao navegar para uma semana mais antiga, pede a partir dela.
  const inicioSemana = semana(dataSelecionada)[0];
  const limiteHistorico = somarDias(hoje(), -HISTORICO_DIAS);
  const { salas, reservas, regras, carregando, erro, aplicar } = useDados(usuario, inicioSemana < limiteHistorico ? inicioSemana : limiteHistorico);
  const [modal, setModal] = useState<{ salaId: number | null } | null>(null);
  const [cancelando, setCancelando] = useState<Reserva | null>(null);

  const navegar = (p: Pagina) => { setPagina(p); setBusca(""); };
  const novo = (salaId: number | null = null) => setModal({ salaId });
  const dias = semana(dataSelecionada);
  const termo = normalizar(busca.trim());
  const ativas = reservas.filter(r => r.status !== "cancelada");
  const combina = (r: Reserva) => normalizar(`${r.atividade} ${r.sala_nome} ${r.responsavel}`).includes(termo);
  const agendaDia = ativas.filter(r => r.data === dataSelecionada && combina(r));
  const proximos = ativas.filter(r => r.status === "confirmada");
  const concluidos = ativas.filter(r => r.status === "concluida");
  const meus = reservas.filter(r => r.usuario_id === usuario.id);
  const porFiltro: Record<Filtro, Reserva[]> = { Todos: ativas, Próximos: proximos, Concluídos: concluidos, Meus: meus };
  const listaReservas = porFiltro[filtro].filter(combina);
  const listaSalas = salas.filter(s => normalizar(`${s.nome} ${s.codigo} ${s.bloco} ${s.tipo} ${s.capacidade} ${s.recursos.join(" ")}`).includes(termo));

  // Ocupação semanal: seg. a sáb., dentro do funcionamento de cada dia (dias bloqueados não contam).
  const janelas = regras ? dias.map(d => (problemaDia(regras, d) ? null : janela(regras, d))) : [];
  const capacidadeMin = janelas.reduce((t, j) => t + (j ? minutos(j.fim) - minutos(j.inicio) : 0), 0) * salas.length;
  const minutosReservados = ativas.reduce((total, r) => {
    const j = janelas[dias.indexOf(r.data)];
    return j ? total + Math.max(0, Math.min(minutos(j.fim), minutos(r.hora_fim)) - Math.max(minutos(j.inicio), minutos(r.hora_inicio))) : total;
  }, 0);
  const ocupacao = capacidadeMin ? Math.min(100, Math.round(minutosReservados / capacidadeMin * 100)) : 0;

  const cabecalho = {
    inicio: { sobretitulo: formatar(dataSelecionada, { weekday: "long", day: "numeric", month: "long" }), titulo: `Olá, ${usuario.nome.split(" ")[0]}!`, descricao: "Acompanhe os espaços e compromissos da sua instituição." },
    agendamentos: { sobretitulo: "Gestão de reservas", titulo: "Agendamentos", descricao: "Agenda geral da instituição — aulas de professores e reservas de alunos." },
    salas: { sobretitulo: "Espaços da instituição", titulo: "Salas", descricao: "Encontre o melhor espaço para sua próxima atividade." },
    admin: { sobretitulo: "Configurações da instituição", titulo: "Administração", descricao: "Cadastre salas, professores e datas sem reservas (feriados e recessos)." },
  }[pagina];

  const TagAluno = ({ r }: { r: Reserva }) => r.perfil_responsavel === "aluno" ? <span className="tag-aluno">Aluno</span> : null;

  return <Layout usuario={usuario} pagina={pagina} onNavegar={navegar} busca={busca} onBusca={setBusca} placeholderBusca="Buscar salas, agendamentos…"
    itens={[{ id: "inicio", icone: "casa", nome: "Início" }, { id: "agendamentos", icone: "calendario", nome: "Agendamentos", contador: proximos.length }, { id: "salas", icone: "porta", nome: "Salas" }, { id: "admin", icone: "engrenagem", nome: "Administração" }]}
    proximos={proximos.filter(r => r.usuario_id === usuario.id)} onAbrirProximos={() => { navegar("agendamentos"); setFiltro("Meus"); }}
    textoNovo="Novo agendamento" onNovo={() => novo()} novoDesabilitado={carregando || !salas.length} onSair={onSair}>

    <CabecalhoPagina {...cabecalho}>
      {pagina === "inicio" && <div className="navegar-semana"><button className="icone-botao" aria-label="Semana anterior" onClick={() => setDataSelecionada(somarDias(dataSelecionada, -7))}><Icon nome="anterior" size={14} /></button><span>{formatar(dias[0], { day: "2-digit", month: "short" })} – {formatar(dias[5], { day: "2-digit", month: "short", year: "numeric" })}</span><button className="icone-botao" aria-label="Próxima semana" onClick={() => setDataSelecionada(somarDias(dataSelecionada, 7))}><Icon nome="proximo" size={14} /></button></div>}
    </CabecalhoPagina>
    {erro && <div className="erro-linha"><div className="erro" role="alert">{erro}</div><button className="link" onClick={() => window.dispatchEvent(new Event("salafacil:atualizar"))}>Tentar novamente</button></div>}

    {pagina === "admin" ? <Administracao usuario={usuario} /> : carregando ? <div className="vazio" role="status">Carregando salas e agendamentos…</div> : <>
      {pagina === "inicio" && <>
        <div className="semana" aria-label="Dias da semana">{dias.map(d => <button key={d} title={regras ? problemaDia(regras, d) ?? undefined : undefined} className={`${d === dataSelecionada ? "selecionado" : ""} ${regras && problemaDia(regras, d) ? "fechado" : ""}`} aria-pressed={d === dataSelecionada} onClick={() => setDataSelecionada(d)}><small>{formatar(d, { weekday: "short" }).replace(".", "")}</small><strong>{dataLocal(d).getDate()}</strong></button>)}</div>
        <div className="dashboard">
          <section><div className="secao-cabecalho"><div><h2>Agenda do dia</h2><small>{agendaDia.length} {agendaDia.length === 1 ? "atividade programada" : "atividades programadas"}</small></div><button className="link" onClick={() => navegar("agendamentos")}>Ver agenda completa</button></div>
            <div className="agenda-dia">{agendaDia.map((r, i) => <article className={`agenda-card cor-${r.perfil_responsavel === "aluno" ? 1 : i % 2 ? 2 : 0}`} key={r.id}><div className="agenda-hora"><strong>{r.hora_inicio}</strong><small>{r.hora_fim}</small></div><div className="agenda-info"><h3>{r.atividade}</h3><p>{r.responsavel} <TagAluno r={r} /></p><div className="agenda-meta"><span className="sala-tag"><Icon nome="local" size={12} />{r.sala_nome}</span><small><Icon nome="relogio" size={12} />{duracao(r.hora_inicio, r.hora_fim)} de duração</small>{r.pessoas && <small><Icon nome="pessoas" size={12} />{r.pessoas} pessoas</small>}</div></div></article>)}
              {!agendaDia.length && <Vazio texto={busca ? "Nenhuma atividade encontrada para esta busca." : "Nenhuma atividade programada para este dia."} />}</div></section>
          <section><div className="secao-cabecalho"><div><h2>Salas agora</h2><small>Disponibilidade em tempo real · atualiza a cada minuto</small></div><button className="link" onClick={() => navegar("salas")}>Ver todas</button></div>
            <div className="salas-resumo painel">{listaSalas.slice(0, 6).map(s => <div className="sala-resumo" key={s.id}><span className={`porta-icone ${s.status === "Ocupada" ? "ocupada" : ""}`}><Icon nome="porta" size={18} /></span><div><h3>{s.nome}</h3><small>{s.capacidade} lugares · {s.bloco}</small></div><span className={`status-texto ${s.status === "Ocupada" ? "ocupada" : ""}`}>● {s.detalhe_status}</span></div>)}
              {!listaSalas.length && <Vazio texto="Nenhuma sala encontrada." />}
              <button className="reservar-livre" onClick={() => novo(salas.find(s => s.status === "Disponível")?.id ?? null)} disabled={!salas.length}><Icon nome="mais" size={14} />Reservar uma sala livre</button></div>
            <div className="ocupacao"><div>Ocupação semanal <Icon nome="grafico" size={17} /></div><strong>{ocupacao}%</strong><div className="progresso" role="progressbar" aria-label="Ocupação semanal" aria-valuenow={ocupacao} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${ocupacao}%` }} /></div><small>Semana selecionada · dentro do horário de funcionamento de cada dia.</small></div></section>
        </div>
      </>}

      {pagina === "agendamentos" && <>
        <div className="filtros" aria-label="Filtrar agendamentos">{(Object.keys(porFiltro) as Filtro[]).map(nome => <button key={nome} className={`botao ${filtro === nome ? "filtro-ativo" : "secundario"}`} aria-pressed={filtro === nome} onClick={() => setFiltro(nome)}>{nome} {porFiltro[nome].length}</button>)}</div>
        <section className="painel lista-agendamentos" aria-label="Agendamentos">{listaReservas.map((r, i) => {
          const [rotulo, classe] = rotuloStatus(r.status);
          return <article className={`agendamento-linha cor-${r.perfil_responsavel === "aluno" ? 1 : i % 2 ? 2 : 0}`} key={r.id}><div className="agendamento-data"><strong>{dataCurta(r.data)}</strong><small>{r.hora_inicio} – {r.hora_fim}</small><small>{dataLocal(r.data).getFullYear()}</small></div><div className="agendamento-atividade"><h3>{r.atividade}</h3><p>{r.responsavel} <TagAluno r={r} /></p></div><span className="sala-tag"><Icon nome="local" size={12} />{r.sala_nome}</span><div className="linha-status"><span className={`badge ${classe}`}>{rotulo}</span>{r.pode_cancelar && <button className="link perigo" onClick={() => setCancelando(r)}>Cancelar</button>}</div></article>;
        })}{!listaReservas.length && <Vazio texto="Nenhum agendamento encontrado para este filtro." />}<footer>Mostrando {listaReservas.length} de {porFiltro[filtro].length} agendamentos</footer></section>
      </>}

      {pagina === "salas" && <>
        <div className="busca-salas painel"><Icon nome="busca" size={17} /><input aria-label="Buscar salas por nome, bloco, tipo ou recurso" placeholder="Buscar por nome, bloco, tipo ou recurso…" value={busca} onChange={e => setBusca(e.target.value)} /><span>{listaSalas.length} espaços</span></div>
        <section className="salas-grid" aria-label="Salas da instituição">{listaSalas.map(s => <article className="sala-card painel com-foto" key={s.id}><FotoSala sala={s} /><div className="sala-card-corpo"><div className="sala-card-topo"><div><h2>{s.nome}</h2><p>{s.tipo} · {s.capacidade} lugares · {s.bloco}</p></div><span className={`badge ${s.status === "Ocupada" ? "ocupada" : ""}`}>● {s.status}</span></div>
          {s.recursos.length > 0 && <div className="chips">{s.recursos.map(r => <span key={r} className="chip">{r}</span>)}</div>}
          <footer><small>{s.detalhe_status}{s.permite_aluno ? " · aberta a alunos" : ""}</small><button className="link" onClick={() => { if (s.status === "Ocupada") { navegar("agendamentos"); setFiltro("Todos"); setBusca(s.nome); } else novo(s.id); }}>{s.status === "Ocupada" ? "Ver agenda" : "Agendar"}</button></footer></div></article>)}</section>
        {!listaSalas.length && <Vazio texto="Nenhuma sala encontrada." />}
      </>}
    </>}

    {modal && regras && <ReservaModalProfessor regras={regras} usuarioId={usuario.id} salas={salas} reservas={reservas} salaInicial={modal.salaId} dataInicial={dataSelecionada} onFechar={() => setModal(null)} onSalvar={r => { aplicar(r); setDataSelecionada(r.data); setBusca(""); setFiltro("Todos"); setPagina("inicio"); }} />}
    {cancelando && <CancelarModal reserva={cancelando} onFechar={() => setCancelando(null)} onCancelada={aplicar} />}
  </Layout>;
}
