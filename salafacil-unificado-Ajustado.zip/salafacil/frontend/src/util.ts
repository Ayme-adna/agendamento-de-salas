import type { Intervalo, Regras, Reserva, StatusReserva } from "./types";

export function hoje() {
  const partes = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const parte = (nome: string) => partes.find(p => p.type === nome)!.value;
  return `${parte("year")}-${parte("month")}-${parte("day")}`;
}
export function dataLocal(data: string) { return new Date(`${data}T12:00:00`); }
export function chaveData(data: Date) { return `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, "0")}-${String(data.getDate()).padStart(2, "0")}`; }
export function somarDias(data: string, dias: number) { const d = dataLocal(data); d.setDate(d.getDate() + dias); return chaveData(d); }
/** Segunda a sábado da semana da data (sábado entra porque há reservas no sábado de manhã). */
export function semana(data: string) {
  const dia = dataLocal(data).getDay();
  const segunda = somarDias(data, -(dia === 0 ? 6 : dia - 1));
  return Array.from({ length: 6 }, (_, i) => somarDias(segunda, i));
}

// ---------- Funcionamento (espelha a validação da API) ----------
const NOS_DIAS = ["às segundas", "às terças", "às quartas", "às quintas", "às sextas", "aos sábados", "aos domingos"];
/** 0 = segunda ... 6 = domingo (mesmo padrão do Python). */
export function diaSemana(data: string) { return (dataLocal(data).getDay() + 6) % 7; }
export function janela(regras: Regras, data: string): Intervalo | null {
  return regras.funcionamento.find(f => f.dia_semana === diaSemana(data)) ?? null;
}
export function problemaDia(regras: Regras, data: string): string | null {
  if (!janela(regras, data)) return `Não há reservas ${NOS_DIAS[diaSemana(data)]}. Funcionamento: segunda a sexta e sábado de manhã.`;
  const b = regras.datas_bloqueadas.find(d => d.data === data);
  if (b) return `Não há reservas em ${formatar(data, { day: "2-digit", month: "2-digit", year: "numeric" })}: ${b.motivo}.`;
  return null;
}
export function problemaPeriodo(regras: Regras, data: string, inicio: string, fim: string): string | null {
  const dia = problemaDia(regras, data);
  if (dia) return dia;
  const j = janela(regras, data)!;
  if (minutos(inicio) < minutos(j.inicio) || minutos(fim) > minutos(j.fim)) {
    const t = NOS_DIAS[diaSemana(data)];
    return `${t[0].toUpperCase()}${t.slice(1)}, as reservas devem ficar entre ${j.inicio} e ${j.fim}.`;
  }
  return null;
}
export function blocosDoDia(regras: Regras, data: string): Intervalo[] {
  const j = janela(regras, data);
  if (!j || problemaDia(regras, data)) return [];
  return regras.blocos_aluno.filter(b => minutos(b.inicio) >= minutos(j.inicio) && minutos(b.fim) <= minutos(j.fim));
}
/** Primeiro dia (a partir de `data`) em que se pode reservar. */
export function proximoDiaAberto(regras: Regras, data: string) {
  let d = data;
  for (let i = 0; i < 60 && problemaDia(regras, d); i++) d = somarDias(d, 1);
  return d;
}
export function formatar(data: string, opcoes: Intl.DateTimeFormatOptions) { return dataLocal(data).toLocaleDateString("pt-BR", opcoes); }
export function dataCurta(data: string) { return formatar(data, { day: "2-digit", month: "short" }).replace(" de ", " ").replace(".", ""); }
export function dataLonga(data: string) { return formatar(data, { weekday: "long", day: "numeric", month: "long", year: "numeric" }); }
export function minutos(hora: string) { const [h, m] = hora.split(":").map(Number); return h * 60 + m; }
export function horasTexto(n: number) {
  if (!n) return "0h";
  return `${Math.floor(n / 60) ? `${Math.floor(n / 60)}h` : ""}${n % 60 ? `${n % 60}min` : ""}`;
}
export function duracao(inicio: string, fim: string) { return horasTexto(minutos(fim) - minutos(inicio)); }
export function sobrepoe(a: { inicio: string; fim: string }, b: { inicio: string; fim: string }) {
  return minutos(a.inicio) < minutos(b.fim) && minutos(a.fim) > minutos(b.inicio);
}
export function normalizar(texto: string) { return texto.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
export function iniciais(nome: string) { return nome.split(" ").filter(Boolean).slice(0, 2).map(p => p[0]).join("").toUpperCase(); }
export function andar(n: number) { return n === 0 ? "Térreo" : `${n}º andar`; }
export function ordenar(lista: Reserva[]) {
  return [...lista].sort((x, y) => `${x.data} ${x.hora_inicio}`.localeCompare(`${y.data} ${y.hora_inicio}`));
}

const ROTULOS: Record<StatusReserva, [string, string]> = {
  confirmada: ["Confirmada", ""],
  concluida: ["Concluída", "concluido"],
  cancelada: ["Cancelada", "cancelado"],
};
export function rotuloStatus(status: StatusReserva) { return ROTULOS[status]; }
