import { useEffect, useState } from "react";
import { EVENTO_SESSAO_EXPIRADA, encerrarSessao, getUsuario, mensagemErro, temSessao } from "./api";
import { AreaAluno } from "./aluno/AreaAluno";
import { Marca } from "./componentes/Comuns";
import { Login } from "./componentes/Login";
import { AreaProfessor } from "./professor/AreaProfessor";
import type { Usuario } from "./types";
import "./styles.css";
import "./unificado.css";

/** Raiz: verifica a sessão e direciona para a área do perfil (professor ou aluno). */
export default function App() {
  const [usuario, setUsuario] = useState<Usuario | null>(null);
  const [verificando, setVerificando] = useState(temSessao);
  const [erro, setErro] = useState("");

  useEffect(() => {
    let ativo = true;
    if (temSessao()) getUsuario().then(u => { if (ativo) setUsuario(u); }).catch(e => { if (ativo) setErro(mensagemErro(e)); }).finally(() => { if (ativo) setVerificando(false); });
    const expirar = () => { setUsuario(null); setErro("Sua sessão expirou. Entre novamente."); };
    window.addEventListener(EVENTO_SESSAO_EXPIRADA, expirar);
    return () => { ativo = false; window.removeEventListener(EVENTO_SESSAO_EXPIRADA, expirar); };
  }, []);

  function sair() { encerrarSessao(); setUsuario(null); setErro(""); }

  if (verificando) return <div className="carregamento" role="status"><Marca /><p>Carregando sua sessão…</p></div>;
  if (!usuario) return <><Login onEntrar={u => { setErro(""); setUsuario(u); }} />{erro && <div className="erro-sessao" role="alert">{erro}</div>}</>;
  return usuario.perfil === "professor"
    ? <AreaProfessor key={usuario.id} usuario={usuario} onSair={sair} />
    : <AreaAluno key={usuario.id} usuario={usuario} onSair={sair} />;
}
