import { useCallback, useEffect, useRef, useState } from "react";
import { EVENTO_ATUALIZAR, getRegras, getReservas, getSalas, mensagemErro } from "./api";
import type { Regras, Reserva, Sala, Usuario } from "./types";
import { ordenar } from "./util";

/** Carrega salas, reservas e regras do usuário logado e mantém tudo atualizado (a cada minuto e ao focar a janela).
 *  `desde`: primeiro dia das reservas (AAAA-MM-DD); ao mudar, recarrega sem mostrar a tela de carregamento. */
export function useDados(usuario: Usuario, desde?: string) {
  const [salas, setSalas] = useState<Sala[]>([]);
  const [reservas, setReservas] = useState<Reserva[]>([]);
  const [regras, setRegras] = useState<Regras | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const carregouUsuario = useRef<number | null>(null);

  useEffect(() => {
    let ativo = true;
    async function carregar(inicial = false) {
      if (inicial) setCarregando(true);
      try {
        const [s, r, g] = await Promise.all([getSalas(), getReservas(desde), getRegras()]);
        if (ativo) { setSalas(s); setReservas(ordenar(r)); setRegras(g); setErro(""); carregouUsuario.current = usuario.id; }
      } catch (e) { if (ativo) setErro(mensagemErro(e)); }
      finally { if (ativo) setCarregando(false); }
    }
    void carregar(carregouUsuario.current !== usuario.id);
    const timer = window.setInterval(() => void carregar(), 60000);
    const atualizar = () => void carregar();
    window.addEventListener("focus", atualizar);
    window.addEventListener(EVENTO_ATUALIZAR, atualizar);
    return () => { ativo = false; clearInterval(timer); window.removeEventListener("focus", atualizar); window.removeEventListener(EVENTO_ATUALIZAR, atualizar); };
  }, [usuario.id, desde]);

  /** Atualiza/insere uma reserva localmente (resposta da API) e pede recarga em segundo plano. */
  const aplicar = useCallback((reserva: Reserva) => {
    setReservas(atuais => ordenar([...atuais.filter(r => r.id !== reserva.id), reserva]));
    window.dispatchEvent(new Event(EVENTO_ATUALIZAR));
  }, []);

  return { salas, reservas, regras, carregando, erro, aplicar };
}

export function recarregar() { window.dispatchEvent(new Event(EVENTO_ATUALIZAR)); }
