import { useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import { getSalas, mensagemErro } from "../api";
import { CancelarModal } from "../componentes/CancelarModal";
import { CabecalhoModal, Erro, FotoSala, Modal, Vazio } from "../componentes/Comuns";
import { Comprovante } from "../componentes/Comprovante";
import { Icon } from "../componentes/Icon";
import { CabecalhoPagina, Layout } from "../componentes/Layout";
import type { Regras, Reserva, Sala, Usuario } from "../types";
import { useDados } from "../useDados";
import { andar, blocosDoDia, dataCurta, dataLocal, formatar, hoje, horasTexto, minutos, normalizar, problemaDia, proximoDiaAberto, rotuloStatus, somarDias } from "../util";
import { ReservaModalAluno } from "./ReservaModalAluno";

type Pagina = "inicio" | "buscar" | "reservas";
type Filtro = "Próximas" | "Concluídas" | "Canceladas" | "Todas";

function agoraHHMM() {
  return new Intl.DateTimeFormat("en-GB", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date());
}
/** Blocos que ainda podem ser reservados no dia (respeita funcionamento, datas bloqueadas e hora atual). */
function blocosLivres(regras: Regras, data: string) {
  const blocos = blocosDoDia(regras, data);
  return data === hoje() ? blocos.filter(b => minutos(b.inicio) > minutos(agoraHHMM())) : blocos;
}
/** Primeiro dia, a partir de hoje, que ainda tem algum bloco disponível. */
function primeiroDiaComBloco(regras: Regras) {
  let d = hoje();
  for (let i = 0; i < 60 && !blocosLivres(regras, d).length; i++) d = proximoDiaAberto(regras, somarDias(d, 1));
  return d;
}
function blocoPadrao(regras: Regras | null, data: string) {
  if (!regras) return "";
  return (blocosLivres(regras, data)[0] ?? blocosDoDia(regras, data)[0])?.inicio ?? "";
}

export function AreaAluno({ usuario, onSair }: { usuario: Usuario; onSair: () => void }) {
  const { salas, reservas, regras, carregando, erro, aplicar } = useDados(usuario);
  const [pagina, setPagina] = useState<Pagina>("inicio");
  const [busca, setBusca] = useState("");
  const [filtro, setFiltro] = useState<Filtro>("Próximas");
  const [cancelando, setCancelando] = useState<Reserva | null>(null);
  const [comprovante, setComprovante] = useState<Reserva | null>(null);
  const [reservando, setReservando] = useState<Sala | null>(null);

  // Filtros da busca de salas (vieram do portal do estudante).
  const [data, setData] = useState(hoje);
  const [bloco, setBloco] = useState("");
  const [pessoas, setPessoas] = useState("4");
  const [soDisponiveis, setSoDisponiveis] = useState(true);
  const [resultado, setResultado] = useState<Sala[] | null>(null);
  const [erroBusca, setErroBusca] = useState("");
  const [buscando, setBuscando] = useState(false);

  // Na primeira carga: se não sobra nenhum período hoje, a busca já começa no dia seguinte.
  const inicializado = useRef(false);
  useEffect(() => {
    if (!regras || inicializado.current) return;
    inicializado.current = true;
    const dia = primeiroDiaComBloco(regras);
    setData(dia); setBloco(blocoPadrao(regras, dia));
  }, [regras]);
  const blocosData = regras ? blocosDoDia(regras, data) : [];
  const blocoAtual = blocosData.find(b => b.inicio === bloco);
  const diaFechado = regras ? problemaDia(regras, data) : null;

  async function buscarSalas(event?: FormEvent) {
    event?.preventDefault();
    if (!blocoAtual) return;
    setErroBusca(""); setBuscando(true);
    try { setResultado(await getSalas({ data, inicio: blocoAtual.inicio, fim: blocoAtual.fim, pessoas: Number(pessoas) || 1 })); }
    catch (e) { setErroBusca(mensagemErro(e)); }
    finally { setBuscando(false); }
  }
  useEffect(() => { if (pagina === "buscar" && blocoAtual && resultado === null) void buscarSalas(); }, [pagina, blocoAtual]); // eslint-disable-line react-hooks/exhaustive-deps

  const navegar = (p: Pagina) => { setPagina(p); setBusca(""); };
  const termo = normalizar(busca.trim());
  const proximas = reservas.filter(r => r.status === "confirmada");
  const porFiltro: Record<Filtro, Reserva[]> = {
    Próximas: proximas, Concluídas: reservas.filter(r => r.status === "concluida"),
    Canceladas: reservas.filter(r => r.status === "cancelada"), Todas: [...reservas].reverse(),
  };
  const lista = porFiltro[filtro].filter(r => normalizar(`${r.atividade} ${r.sala_nome} ${r.codigo}`).includes(termo));
  const salasEncontradas = (resultado ?? []).filter(s => (!soDisponiveis || s.disponivel_periodo) && normalizar(`${s.nome} ${s.bloco} ${s.tipo} ${s.recursos.join(" ")}`).includes(termo));
  const salasAgora = salas.filter(s => normalizar(`${s.nome} ${s.bloco} ${s.recursos.join(" ")}`).includes(termo));
  const usadoHoje = reservas.filter(r => r.data === hoje() && r.status !== "cancelada").reduce((t, r) => t + minutos(r.hora_fim) - minutos(r.hora_inicio), 0);
  const limite = regras?.limite_diario_aluno_min ?? 120;
  const salaDe = (r: Reserva) => salas.find(s => s.id === r.sala_id);

  const cabecalho = {
    inicio: { sobretitulo: formatar(hoje(), { weekday: "long", day: "numeric", month: "long" }), titulo: `Olá, ${usuario.nome.split(" ")[0]}!`, descricao: "Suas reservas e as salas de estudo disponíveis agora." },
    buscar: { sobretitulo: "Espaços de estudo", titulo: "Encontre seu próximo espaço de ideias", descricao: `Reservas em períodos de 2 horas · até ${limite / 60}h por dia · gratuitas.` },
    reservas: { sobretitulo: "Seu histórico", titulo: "Minhas reservas", descricao: "Consulte comprovantes e cancele reservas que ainda não começaram." },
  }[pagina];

  return <Layout usuario={usuario} pagina={pagina} onNavegar={navegar} busca={busca} onBusca={setBusca}
    placeholderBusca={pagina === "reservas" ? "Buscar nas minhas reservas…" : "Buscar salas ou recursos…"}
    itens={[{ id: "inicio", icone: "casa", nome: "Início" }, { id: "buscar", icone: "busca", nome: "Buscar salas" }, { id: "reservas", icone: "lista", nome: "Minhas reservas", contador: proximas.length }]}
    proximos={proximas} onAbrirProximos={() => { navegar("reservas"); setFiltro("Próximas"); }}
    textoNovo="Nova reserva" onNovo={() => navegar("buscar")} novoDesabilitado={carregando} onSair={onSair}>

    <CabecalhoPagina {...cabecalho} />
    {erro && <div className="erro-linha"><div className="erro" role="alert">{erro}</div><button className="link" onClick={() => window.dispatchEvent(new Event("salafacil:atualizar"))}>Tentar novamente</button></div>}

    {carregando ? <div className="vazio" role="status">Carregando suas reservas…</div> : <>
      {pagina === "inicio" && <div className="dashboard">
        <section><div className="secao-cabecalho"><div><h2>Próximas reservas</h2><small>{proximas.length} {proximas.length === 1 ? "reserva confirmada" : "reservas confirmadas"}</small></div><button className="link" onClick={() => navegar("reservas")}>Ver todas</button></div>
          <div className="agenda-dia">{proximas.filter(r => normalizar(`${r.atividade} ${r.sala_nome}`).includes(termo)).slice(0, 5).map((r, i) => <article className={`agenda-card cor-${i % 3}`} key={r.id}><div className="agenda-hora"><strong>{dataCurta(r.data)}</strong><small>{r.hora_inicio} – {r.hora_fim}</small></div><div className="agenda-info"><h3>{r.atividade}</h3><p>Comprovante {r.codigo}</p><div className="agenda-meta"><span className="sala-tag"><Icon nome="local" size={12} />{r.sala_nome}</span><small><Icon nome="pessoas" size={12} />{r.pessoas} pessoas</small><button className="link" onClick={() => setComprovante(r)}>Ver comprovante</button></div></div></article>)}
            {!proximas.length && <div className="vazio"><Icon nome="calendario" size={28} /><p>Você ainda não tem reservas futuras.</p><button className="botao primario" onClick={() => navegar("buscar")}><Icon nome="busca" size={15} />Encontrar uma sala</button></div>}</div></section>
        <section><div className="secao-cabecalho"><div><h2>Salas de estudo agora</h2><small>Disponibilidade em tempo real</small></div><button className="link" onClick={() => navegar("buscar")}>Buscar</button></div>
          <div className="salas-resumo painel">{salasAgora.slice(0, 6).map(s => <div className="sala-resumo" key={s.id}><span className={`porta-icone ${s.status === "Ocupada" ? "ocupada" : ""}`}><Icon nome="porta" size={18} /></span><div><h3>{s.nome}</h3><small>{s.capacidade} lugares · {s.bloco}</small></div><span className={`status-texto ${s.status === "Ocupada" ? "ocupada" : ""}`}>● {s.detalhe_status}</span></div>)}
            {!salasAgora.length && <Vazio texto="Nenhuma sala encontrada." />}
            <button className="reservar-livre" onClick={() => navegar("buscar")}><Icon nome="mais" size={14} />Reservar uma sala</button></div>
          <div className="ocupacao"><div>Seu limite hoje <Icon nome="relogio" size={17} /></div><strong>{horasTexto(usadoHoje)} <small>de {horasTexto(limite)}</small></strong><div className="progresso" role="progressbar" aria-label="Horas reservadas hoje" aria-valuenow={usadoHoje} aria-valuemin={0} aria-valuemax={limite}><span style={{ width: `${Math.min(100, usadoHoje / limite * 100)}%` }} /></div><small>Cada aluno pode reservar até {limite / 60} horas por dia.</small></div></section>
      </div>}

      {pagina === "buscar" && <>
        <form className="painel filtros-busca" onSubmit={buscarSalas}>
          <div><label htmlFor="f-data">Data</label><input id="f-data" type="date" min={hoje()} value={data} onChange={e => { setData(e.target.value); setBloco(blocoPadrao(regras, e.target.value)); setResultado(null); }} required /></div>
          <div><label htmlFor="f-bloco">Horário</label><select id="f-bloco" value={blocoAtual ? bloco : ""} onChange={e => setBloco(e.target.value)} disabled={!blocosData.length}>{!blocosData.length && <option value="">Fechado</option>}{blocosData.map(b => <option key={b.inicio} value={b.inicio}>{b.inicio} – {b.fim}</option>)}</select></div>
          <div><label htmlFor="f-pessoas">Pessoas</label><input id="f-pessoas" type="number" min={1} value={pessoas} onChange={e => setPessoas(e.target.value)} required /></div>
          <label className="checkbox"><input type="checkbox" checked={soDisponiveis} onChange={e => setSoDisponiveis(e.target.checked)} />Só disponíveis</label>
          <button className="botao primario" disabled={buscando || !blocoAtual}><Icon nome="busca" size={15} />{buscando ? "Buscando…" : "Buscar salas"}</button>
        </form>
        {diaFechado && <p className="aviso alerta">{diaFechado}</p>}
        <Erro texto={erroBusca} />
        {resultado && blocoAtual && <div className="secao-cabecalho"><div><h2>{salasEncontradas.length} {salasEncontradas.length === 1 ? "sala encontrada" : "salas encontradas"}</h2><small className="primeira-maiuscula">{formatar(data, { weekday: "long", day: "2-digit", month: "long" })} · {blocoAtual.inicio} às {blocoAtual.fim} · {pessoas} pessoas</small></div></div>}
        <section className="salas-grid" aria-label="Salas encontradas">{salasEncontradas.map(s => <article className="sala-card painel com-foto" key={s.id}><FotoSala sala={s} /><div className="sala-card-corpo"><div className="sala-card-topo"><div><h2>{s.nome}</h2><p>{s.bloco} · {andar(s.andar)} · até {s.capacidade} pessoas</p></div><span className={`badge ${s.disponivel_periodo ? "" : "ocupada"}`}>● {s.disponivel_periodo ? "Disponível" : "Ocupada"}</span></div>
          {s.recursos.length > 0 && <div className="chips">{s.recursos.map(r => <span key={r} className="chip">{r}</span>)}</div>}
          <footer><small>{blocoAtual?.inicio} – {blocoAtual?.fim}</small>{s.disponivel_periodo ? <button className="botao primario pequeno" onClick={() => setReservando(s)}>Reservar</button> : <small>Tente outro horário</small>}</footer></div></article>)}</section>
        {resultado && blocoAtual && !salasEncontradas.length && <Vazio texto="Nenhuma sala disponível com esses filtros. Tente outro horário ou menos pessoas." />}
      </>}

      {pagina === "reservas" && <>
        <div className="filtros" aria-label="Filtrar reservas">{(Object.keys(porFiltro) as Filtro[]).map(nome => <button key={nome} className={`botao ${filtro === nome ? "filtro-ativo" : "secundario"}`} aria-pressed={filtro === nome} onClick={() => setFiltro(nome)}>{nome} {porFiltro[nome].length}</button>)}</div>
        <section className="painel lista-agendamentos" aria-label="Minhas reservas">{lista.map((r, i) => {
          const [rotulo, classe] = rotuloStatus(r.status);
          return <article className={`agendamento-linha cor-${i % 3}`} key={r.id}><div className="agendamento-data"><strong>{dataCurta(r.data)}</strong><small>{r.hora_inicio} – {r.hora_fim}</small><small>{dataLocal(r.data).getFullYear()}</small></div><div className="agendamento-atividade"><h3>{r.atividade}</h3><p>{r.codigo} · {r.pessoas} pessoas · <button className="link" onClick={() => setComprovante(r)}>Comprovante</button></p></div><span className="sala-tag"><Icon nome="local" size={12} />{r.sala_nome}</span><div className="linha-status"><span className={`badge ${classe}`}>{rotulo}</span>{r.pode_cancelar && <button className="link perigo" onClick={() => setCancelando(r)}>Cancelar</button>}</div></article>;
        })}{!lista.length && <Vazio texto="Nenhuma reserva encontrada para este filtro." />}<footer>Mostrando {lista.length} de {porFiltro[filtro].length} reservas</footer></section>
      </>}
    </>}

    {reservando && regras && <ReservaModalAluno usuario={usuario} sala={reservando} regras={regras} minhasReservas={reservas} dataInicial={data} blocoInicial={bloco} pessoasInicial={Number(pessoas) || 1}
      onFechar={() => { setReservando(null); void buscarSalas(); }} onSalvar={aplicar} onVerReservas={() => { setReservando(null); setResultado(null); navegar("reservas"); setFiltro("Próximas"); }} />}
    {cancelando && <CancelarModal reserva={cancelando} onFechar={() => setCancelando(null)} onCancelada={aplicar} />}
    {comprovante && <Modal titulo="Comprovante" onFechar={() => setComprovante(null)} className="modal-largo"><CabecalhoModal titulo="Comprovante de reserva" onFechar={() => setComprovante(null)} /><Comprovante reserva={comprovante} sala={salaDe(comprovante)} usuario={usuario} /><div className="modal-acoes nao-imprimir"><button className="botao secundario" onClick={() => window.print()}><Icon nome="imprimir" size={15} />Imprimir</button><button className="botao primario" onClick={() => setComprovante(null)}>Fechar</button></div></Modal>}
  </Layout>;
}
