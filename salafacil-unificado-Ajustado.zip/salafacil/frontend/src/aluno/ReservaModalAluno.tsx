import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { criarReserva, getDisponibilidade, mensagemErro } from "../api";
import { CabecalhoModal, Erro, FotoSala, Modal } from "../componentes/Comuns";
import { Comprovante } from "../componentes/Comprovante";
import { Icon } from "../componentes/Icon";
import type { Intervalo, Regras, Reserva, Sala, Usuario } from "../types";
import { andar, blocosDoDia, dataLonga, hoje, minutos, problemaDia, sobrepoe } from "../util";

interface Props {
  usuario: Usuario;
  sala: Sala;
  regras: Regras;
  minhasReservas: Reserva[];
  dataInicial: string;
  blocoInicial: string;
  pessoasInicial: number;
  onFechar: () => void;
  onSalvar: (reserva: Reserva) => void;
  onVerReservas: () => void;
}

function agoraMinutos() {
  const p = new Intl.DateTimeFormat("en-GB", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date());
  return minutos(p);
}

/** Reserva do aluno: blocos fixos de 2h, número de pessoas, finalidade e aceite das regras. */
export function ReservaModalAluno({ usuario, sala, regras, minhasReservas, dataInicial, blocoInicial, pessoasInicial, onFechar, onSalvar, onVerReservas }: Props) {
  const [data, setData] = useState(dataInicial < hoje() ? hoje() : dataInicial);
  const [bloco, setBloco] = useState(blocoInicial);
  const [pessoas, setPessoas] = useState(String(Math.min(pessoasInicial, sala.capacidade)));
  const [finalidade, setFinalidade] = useState("Trabalho em grupo");
  const [aceite, setAceite] = useState(false);
  const [ocupados, setOcupados] = useState<Intervalo[] | null>(null);
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [confirmada, setConfirmada] = useState<Reserva | null>(null);

  useEffect(() => {
    let ativo = true;
    setOcupados(null);
    getDisponibilidade(sala.id, data).then(o => { if (ativo) setOcupados(o); }).catch(e => { if (ativo) { setOcupados([]); setErro(mensagemErro(e)); } });
    return () => { ativo = false; };
  }, [sala.id, data]);

  const usadoNoDia = minhasReservas.filter(r => r.data === data && r.status === "confirmada").reduce((t, r) => t + minutos(r.hora_fim) - minutos(r.hora_inicio), 0);
  const limiteAtingido = usadoNoDia >= regras.limite_diario_aluno_min;
  const fechado = problemaDia(regras, data);
  const blocos = blocosDoDia(regras, data);
  const situacao = (b: Intervalo) => {
    if (data === hoje() && minutos(b.inicio) <= agoraMinutos()) return "Encerrado";
    if (minhasReservas.some(r => r.status === "confirmada" && r.data === data && sobrepoe(b, { inicio: r.hora_inicio, fim: r.hora_fim }))) return "Você já reservou";
    if (ocupados?.some(o => sobrepoe(b, o))) return "Indisponível";
    return "Disponível";
  };
  const blocoAtual = blocos.find(b => b.inicio === bloco);
  const blocoValido = blocoAtual && situacao(blocoAtual) === "Disponível";

  async function salvar(event: FormEvent) {
    event.preventDefault(); setErro("");
    if (!blocoAtual || !blocoValido) { setErro("Escolha um horário disponível."); return; }
    if (!Number(pessoas) || Number(pessoas) > sala.capacidade) { setErro(`Informe de 1 a ${sala.capacidade} pessoas.`); return; }
    if (!aceite) { setErro("Aceite as regras de uso para continuar."); return; }
    setSalvando(true);
    try {
      const r = await criarReserva({ sala_id: sala.id, data, hora_inicio: blocoAtual.inicio, hora_fim: blocoAtual.fim, pessoas: Number(pessoas), atividade: finalidade.trim() || "Estudo em grupo" });
      onSalvar(r); setConfirmada(r);
    } catch (e) { setErro(mensagemErro(e)); }
    finally { setSalvando(false); }
  }

  if (confirmada) return <Modal titulo="Reserva confirmada" onFechar={onFechar} className="modal-largo">
    <div className="sucesso-cabecalho"><span className="sucesso-icone"><Icon nome="check" size={27} /></span><h2>Tudo certo. A sala é de vocês!</h2><p>Sua reserva foi confirmada. Agora é só reunir o grupo e trazer suas ideias.</p></div>
    <Comprovante reserva={confirmada} sala={sala} usuario={usuario} />
    <div className="modal-acoes nao-imprimir"><button className="botao secundario" onClick={() => window.print()}><Icon nome="imprimir" size={15} />Imprimir</button><button autoFocus className="botao primario" onClick={onVerReservas}>Ver minhas reservas</button></div>
  </Modal>;

  return <Modal titulo={`Reservar ${sala.nome}`} onFechar={onFechar} bloqueado={salvando} className="modal-largo"><form onSubmit={salvar}>
    <CabecalhoModal titulo="Prepare seu próximo encontro de estudo" onFechar={onFechar} bloqueado={salvando} />
    <div className="sala-destaque"><FotoSala sala={sala} className="pequena" /><div><h3>{sala.nome}</h3><small>{sala.bloco} · {andar(sala.andar)} · {sala.campus} · até {sala.capacidade} pessoas</small>{sala.descricao && <p>{sala.descricao}</p>}{sala.recursos.length > 0 && <div className="chips">{sala.recursos.map(r => <span className="chip" key={r}>{r}</span>)}</div>}</div></div>
    <fieldset disabled={salvando}>
      <label htmlFor="data-aluno">Quando vamos estudar?</label><input id="data-aluno" type="date" min={hoje()} value={data} onChange={e => { setData(e.target.value); setErro(""); }} required />
      <small className="primeira-maiuscula bloco">{dataLonga(data)} · períodos de 2 horas · horário de Brasília</small>
      {fechado && <p className="aviso alerta">{fechado}</p>}
      <div className="slots" role="radiogroup" aria-label="Horário">{blocos.map(b => {
        const s = ocupados === null ? "Carregando…" : situacao(b);
        const sel = b.inicio === bloco && s === "Disponível";
        return <button type="button" role="radio" aria-checked={sel} key={b.inicio} className={`slot ${sel ? "sel" : ""}`} disabled={s !== "Disponível"} onClick={() => setBloco(b.inicio)}>{b.inicio} – {b.fim}<small>{sel ? "Selecionado" : s}</small></button>;
      })}</div>
      {limiteAtingido && <p className="aviso">Você já usou suas {regras.limite_diario_aluno_min / 60} horas de reserva neste dia. Escolha outra data.</p>}
      <div className="form-linha aluno"><div><label htmlFor="pessoas-aluno">Pessoas</label><input id="pessoas-aluno" type="number" min={1} max={sala.capacidade} value={pessoas} onChange={e => setPessoas(e.target.value)} required /></div><div><label htmlFor="finalidade">Finalidade do encontro</label><input id="finalidade" maxLength={200} value={finalidade} onChange={e => setFinalidade(e.target.value)} /></div></div>
      <label className="checkbox aceite"><input type="checkbox" checked={aceite} onChange={e => setAceite(e.target.checked)} /><span>Li e concordo com as regras de uso: até {regras.limite_diario_aluno_min / 60}h por dia, chegada em até 15 minutos após o início e sala organizada ao sair.</span></label>
      <Erro texto={erro} />
      <div className="modal-acoes"><button className="botao secundario" type="button" onClick={onFechar}>Voltar</button><button className="botao primario" type="submit" disabled={salvando || limiteAtingido || !blocoValido}><Icon nome="check" size={15} />{salvando ? "Confirmando…" : "Confirmar reserva"}</button></div>
    </fieldset>
  </form></Modal>;
}
