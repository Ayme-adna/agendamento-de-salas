import { useState } from "react";
import type { ReactNode } from "react";
import type { Reserva, Usuario } from "../types";
import { dataCurta, iniciais } from "../util";
import { Marca } from "./Comuns";
import { Icon } from "./Icon";
import type { Icone } from "./Icon";

export interface ItemMenu<P extends string> { id: P; icone: Icone; nome: string; contador?: number }

interface Props<P extends string> {
  usuario: Usuario;
  itens: ItemMenu<P>[];
  pagina: P;
  onNavegar: (p: P) => void;
  busca: string;
  onBusca: (texto: string) => void;
  placeholderBusca: string;
  proximos: Reserva[];
  onAbrirProximos: () => void;
  textoNovo: string;
  onNovo: () => void;
  novoDesabilitado?: boolean;
  onSair: () => void;
  children: ReactNode;
}

/** Estrutura comum (sidebar + topbar) para as áreas do professor e do aluno. */
export function Layout<P extends string>(props: Props<P>) {
  const { usuario, itens, pagina, onNavegar, busca, onBusca, placeholderBusca, proximos, onAbrirProximos, textoNovo, onNovo, novoDesabilitado, onSair, children } = props;
  const [notificacoes, setNotificacoes] = useState(false);
  const navegar = (p: P) => { setNotificacoes(false); onNavegar(p); };
  return <div className="app">
    <aside className="sidebar"><Marca /><span className="menu-legenda">Menu principal</span>
      <nav aria-label="Menu principal">{itens.map(item => <button key={item.id} className={`nav-item ${pagina === item.id ? "ativo" : ""}`} aria-current={pagina === item.id ? "page" : undefined} onClick={() => navegar(item.id)}><Icon nome={item.icone} /><span>{item.nome}</span>{item.contador !== undefined && <span className="contador">{item.contador}</span>}</button>)}</nav>
      <div className="sidebar-rodape"><button className="nav-item" onClick={onSair}><Icon nome="sair" /><span>Sair do sistema</span></button>
        <div className="perfil"><span className={`avatar ${usuario.perfil}`}>{iniciais(usuario.nome)}</span><div><strong>{usuario.nome}</strong><small>{usuario.perfil === "aluno" ? `Aluno · ${usuario.matricula ?? usuario.cargo}` : usuario.cargo}</small></div><button className="icone-botao" aria-label="Sair do sistema" onClick={onSair}><Icon nome="sair" /></button></div>
      </div>
    </aside>
    <div className="app-corpo">
      <header className="topbar">
        <div className="busca-global"><Icon nome="busca" size={15} /><input aria-label={placeholderBusca} placeholder={placeholderBusca} value={busca} onChange={e => onBusca(e.target.value)} /></div>
        <div className="topbar-acoes">
          <div className="notificacoes"><button className="icone-botao sino" aria-label="Ver próximas reservas" aria-expanded={notificacoes} onClick={() => setNotificacoes(!notificacoes)}><Icon nome="sino" />{proximos.length > 0 && <i />}</button>
            {notificacoes && <div className="notificacoes-painel"><strong>Próximas reservas</strong>{proximos.slice(0, 3).map(a => <button key={a.id} onClick={() => { setNotificacoes(false); onAbrirProximos(); }}><b>{a.atividade}</b><small>{dataCurta(a.data)} · {a.hora_inicio} – {a.hora_fim} · {a.sala_nome}</small></button>)}{!proximos.length && <p>Nenhuma reserva próxima.</p>}</div>}
          </div>
          <button className="botao primario" disabled={novoDesabilitado} onClick={() => { setNotificacoes(false); onNovo(); }}><Icon nome="mais" size={15} />{textoNovo}</button>
        </div>
      </header>
      <main className="conteudo">{children}</main>
    </div>
  </div>;
}

export function CabecalhoPagina({ sobretitulo, titulo, descricao, children }: { sobretitulo: string; titulo: string; descricao: string; children?: ReactNode }) {
  return <div className="pagina-cabecalho"><div><span className="sobretitulo">{sobretitulo}</span><h1>{titulo}</h1><p>{descricao}</p></div>{children}</div>;
}
