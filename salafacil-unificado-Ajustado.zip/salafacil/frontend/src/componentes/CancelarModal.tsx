import { useState } from "react";
import { cancelarReserva, mensagemErro } from "../api";
import type { Reserva } from "../types";
import { dataCurta } from "../util";
import { CabecalhoModal, Erro, Modal } from "./Comuns";

/** Confirmação de cancelamento (substitui o confirm() do navegador). */
export function CancelarModal({ reserva, onFechar, onCancelada }: { reserva: Reserva; onFechar: () => void; onCancelada: (r: Reserva) => void }) {
  const [erro, setErro] = useState("");
  const [enviando, setEnviando] = useState(false);
  async function confirmar() {
    setErro(""); setEnviando(true);
    try { onCancelada(await cancelarReserva(reserva.id)); onFechar(); }
    catch (e) { setErro(mensagemErro(e)); }
    finally { setEnviando(false); }
  }
  return <Modal titulo="Cancelar reserva" onFechar={onFechar} bloqueado={enviando}>
    <CabecalhoModal titulo="Cancelar reserva" onFechar={onFechar} bloqueado={enviando} />
    <p>Você vai liberar <b>{reserva.sala_nome}</b> em {dataCurta(reserva.data)}, das {reserva.hora_inicio} às {reserva.hora_fim}. Essa ação não pode ser desfeita.</p>
    <Erro texto={erro} />
    <div className="modal-acoes"><button className="botao secundario" onClick={onFechar} disabled={enviando}>Manter reserva</button><button autoFocus className="botao perigo" onClick={confirmar} disabled={enviando}>{enviando ? "Cancelando…" : "Cancelar reserva"}</button></div>
  </Modal>;
}
