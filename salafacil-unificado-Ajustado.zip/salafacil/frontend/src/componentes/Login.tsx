import { useState } from "react";
import type { FormEvent } from "react";
import { cadastrar, entrar, mensagemErro } from "../api";
import type { Usuario } from "../types";
import { Erro, Marca } from "./Comuns";
import { Icon } from "./Icon";

type Aba = "entrar" | "cadastrar";

export function Login({ onEntrar }: { onEntrar: (usuario: Usuario) => void }) {
  const [aba, setAba] = useState<Aba>("entrar");
  const [nome, setNome] = useState("");
  const [login, setLogin] = useState("");
  const [senha, setSenha] = useState("");
  const [manter, setManter] = useState(true);
  const [erro, setErro] = useState("");
  const [ajuda, setAjuda] = useState(false);
  const [enviando, setEnviando] = useState(false);

  function trocar(nova: Aba) { setAba(nova); setErro(""); setAjuda(false); setSenha(""); }
  async function enviar(event: FormEvent) {
    event.preventDefault(); setErro(""); setEnviando(true);
    try { onEntrar(aba === "entrar" ? await entrar(login.trim(), senha, manter) : await cadastrar(nome.trim(), login.trim(), senha)); }
    catch (e) { setErro(mensagemErro(e)); }
    finally { setEnviando(false); }
  }

  return <div className="login">
    <section className="login-apresentacao"><Marca /><div className="login-chamada"><span className="porta-grande"><Icon nome="porta" size={30} /></span><h1>Todos os espaços da sua<br />escola, organizados.</h1><p>Professores agendam aulas e alunos reservam salas de estudo<br className="desktop" /> — tudo na mesma agenda, sem conflitos.</p></div><footer><span>✓ &nbsp; Reservas rápidas</span><span>✓ &nbsp; Agenda centralizada</span><span>✓ &nbsp; Professores e alunos</span></footer></section>
    <main className="login-painel"><form onSubmit={enviar} className="login-form">
      <h2>{aba === "entrar" ? "Boas-vindas de volta" : "Crie sua conta"}</h2>
      <p className="subtitulo">{aba === "entrar" ? "Entre com seu e-mail institucional ou matrícula para acessar as salas." : "Cadastro para estudantes. Professores recebem o acesso da instituição."}</p>
      <div className="abas" role="tablist">
        <button type="button" role="tab" aria-selected={aba === "entrar"} className={aba === "entrar" ? "ativa" : ""} onClick={() => trocar("entrar")}>Entrar</button>
        <button type="button" role="tab" aria-selected={aba === "cadastrar"} className={aba === "cadastrar" ? "ativa" : ""} onClick={() => trocar("cadastrar")}>Sou aluno — cadastrar</button>
      </div>
      {aba === "cadastrar" && <><label htmlFor="nome">Nome completo</label><div className="campo-icone"><Icon nome="usuario" /><input id="nome" autoComplete="name" maxLength={150} value={nome} onChange={e => setNome(e.target.value)} placeholder="Seu nome" required minLength={3} /></div></>}
      <label htmlFor="login">{aba === "entrar" ? "E-mail institucional ou matrícula" : "Matrícula ou e-mail institucional"}</label>
      <div className="campo-icone"><Icon nome="email" /><input id="login" autoComplete="username" maxLength={150} value={login} onChange={e => setLogin(e.target.value)} placeholder="seu.email@escola.edu.br ou 2026001" required /></div>
      <label htmlFor="senha">{aba === "entrar" ? "Senha" : "Senha (mínimo 6 caracteres)"}</label>
      <div className="campo-icone"><Icon nome="cadeado" /><input id="senha" type="password" autoComplete={aba === "entrar" ? "current-password" : "new-password"} minLength={aba === "cadastrar" ? 6 : undefined} maxLength={255} value={senha} onChange={e => setSenha(e.target.value)} placeholder="••••••••" required /></div>
      {aba === "entrar" ? <div className="login-opcoes"><label className="checkbox"><input type="checkbox" checked={manter} onChange={e => setManter(e.target.checked)} />Manter conectado</label><button type="button" className="link" onClick={() => setAjuda(!ajuda)}>Esqueci minha senha</button></div> : <div className="login-opcoes" />}
      {ajuda && <p className="aviso" role="status">Para recuperar seu acesso, entre em contato com a secretaria da sua instituição.</p>}
      <Erro texto={erro} />
      <button className="botao primario login-enviar" disabled={enviando}>{enviando ? "Aguarde…" : aba === "entrar" ? "Entrar no sistema" : "Criar conta e entrar"}</button>
      <p className="login-rodape">Em caso de dúvidas, contate a secretaria.</p>
    </form></main>
  </div>;
}
