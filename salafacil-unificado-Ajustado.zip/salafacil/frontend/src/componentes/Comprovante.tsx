import type { Reserva, Sala, Usuario } from "../types";
import { andar, dataLonga, duracao, rotuloStatus } from "../util";
import { FotoSala } from "./Comuns";
import { Icon } from "./Icon";

/** Comprovante da reserva (veio do portal do aluno). Também é a tela de sucesso após reservar. */
export function Comprovante({ reserva, sala, usuario }: { reserva: Reserva; sala?: Sala; usuario: Usuario }) {
  const [rotulo, classe] = rotuloStatus(reserva.status);
  return <div className="comprovante">
    <div className="comprovante-topo"><div><small>COMPROVANTE DE RESERVA</small><h3>{reserva.codigo}</h3></div><span className={`badge ${classe}`}>{rotulo}</span></div>
    <div className="comprovante-corpo">
      {sala && <FotoSala sala={sala} className="pequena" />}
      <ul>
        <li><Icon nome="porta" size={14} /><b>{reserva.sala_nome}</b>{sala && <small> · {sala.tipo}, até {sala.capacidade} pessoas</small>}</li>
        <li><Icon nome="calendario" size={14} /><span className="primeira-maiuscula">{dataLonga(reserva.data)}</span></li>
        <li><Icon nome="relogio" size={14} />{reserva.hora_inicio} às {reserva.hora_fim} ({duracao(reserva.hora_inicio, reserva.hora_fim)})</li>
        {sala && <li><Icon nome="local" size={14} />{sala.bloco} · {andar(sala.andar)} · {sala.campus}</li>}
        {reserva.pessoas && <li><Icon nome="pessoas" size={14} />{reserva.pessoas} pessoas</li>}
        <li><Icon nome="usuario" size={14} />{usuario.nome}{usuario.matricula ? ` · ${usuario.matricula}` : ""}<small> — {reserva.atividade}</small></li>
      </ul>
    </div>
    {reserva.status === "confirmada" && <p className="comprovante-aviso">Na chegada, apresente sua carteirinha na recepção. Chegue em até 15 minutos após o início.</p>}
  </div>;
}
