import { useEffect, useRef } from "react";
import type { ReactNode } from "react";
import type { Sala } from "../types";
import { Icon } from "./Icon";

export function Marca() {
  return <div className="marca"><span className="marca-icone"><Icon nome="calendario" size={21} /></span><div><strong>SalaFácil</strong><small>Gestão educacional</small></div></div>;
}
export function Erro({ texto }: { texto: string }) { return texto ? <div className="erro" role="alert">{texto}</div> : null; }
export function Vazio({ texto }: { texto: string }) { return <div className="vazio"><Icon nome="calendario" size={28} /><p>{texto}</p></div>; }

/** Foto da sala; quando não existe imagem, mostra um bloco com o ícone de porta. */
export function FotoSala({ sala, className = "" }: { sala: Pick<Sala, "imagem" | "nome">; className?: string }) {
  return sala.imagem
    ? <img className={`sala-foto ${className}`} src={`/img/${sala.imagem}`} alt={`Foto da ${sala.nome}`} loading="lazy" />
    : <div className={`sala-foto sem-foto ${className}`} aria-hidden="true"><Icon nome="porta" size={30} /></div>;
}

/** Modal baseado em <dialog>, no mesmo padrão visual do SalaFácil. */
export function Modal({ titulo, onFechar, bloqueado = false, className = "", children }: {
  titulo?: string; onFechar: () => void; bloqueado?: boolean; className?: string; children: ReactNode;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => { dialog.current?.showModal(); }, []);
  return <dialog ref={dialog} className={`modal ${className}`} aria-label={titulo}
    onCancel={e => { e.preventDefault(); if (!bloqueado) onFechar(); }}
    onClick={e => { if (e.target === e.currentTarget && !bloqueado) onFechar(); }}>
    {children}
  </dialog>;
}

export function CabecalhoModal({ titulo, onFechar, bloqueado = false }: { titulo: string; onFechar: () => void; bloqueado?: boolean }) {
  return <div className="modal-cabecalho"><h2>{titulo}</h2><button className="icone-botao" type="button" aria-label="Fechar" onClick={onFechar} disabled={bloqueado}><Icon nome="fechar" /></button></div>;
}
